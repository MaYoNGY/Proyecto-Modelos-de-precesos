# Proyecto-POO
NRC 9658

## Integrantes
- Julio Viche
- Marjorie Cedeño
- Micaela Salcedo

## Documentación

- [Requisitos](doc/requisitos.md)
- [Clases](doc/clases.md)