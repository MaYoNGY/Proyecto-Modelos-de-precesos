/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.vista;

import com.github.sarxos.webcam.Webcam;
import com.github.sarxos.webcam.WebcamPanel;
import com.github.sarxos.webcam.WebcamResolution;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author dell
 */
public class RegistroQuimioterapia extends javax.swing.JFrame {

    int largoCamara=280;
    int anchoCamara=350;
    Dimension dimension=new Dimension(largoCamara,anchoCamara);
    Dimension dimension1= WebcamResolution.VGA.getSize();
    Webcam webcam= Webcam.getDefault();
    WebcamPanel webcamPanel=new WebcamPanel(webcam,dimension,false);
    BufferedImage ruta;
    int contador=0;
    
    public void guardarImagen(String cedula) {
        File salidaImagen= new File("RecetaPacientesQuimioterapia\\"+cedula+".jpg");

        try{

            ImageIO.write(ruta, "jpg", salidaImagen);
            JOptionPane.showMessageDialog(this, "Imagen guardada en: "+ salidaImagen.getAbsolutePath());
        }
        catch(Exception e){
            System.out.println("Error:"+ e);
        }
    }
    
    public RegistroQuimioterapia() {
        
        initComponents();
        setLocationRelativeTo(null);
        webcam.setViewSize(dimension1);
        webcamPanel.setFillArea(true);
        pnlCamara.setLayout(new FlowLayout());
        pnlCamara.add(webcamPanel);
        lblNombreCamara.setText(webcam.toString());
        
        apagarBotones();
        
    }

    public JButton getAtrasButton() {
        return AtrasButton;
    }
    
   
    public void apagarBotones(){
        btnApagar.setEnabled(false);
        btnCapturarFoto.setEnabled(false);
        btnGuardarFoto.setEnabled(false);
        
    }
    public void prenderBotones(){
         btnApagar.setEnabled(true);
          btnCapturarFoto.setEnabled(true);
        
    }
    public void textoBotonesCuandoCargaCamara(){
     btnApagar.setText("Iniciar camara....");
     btnCapturarFoto.setText("Iniciando camara....");
     btnGuardarFoto.setText("Iniciando camara   ");
     btnIniciar.setText("Iniciando Camara   ");
        
        
    }
    
    public void textoBotonesCuandoCargoCamara(){
           btnApagar.setText("Apagar");
     btnCapturarFoto.setText("Capturar Foto");
     btnGuardarFoto.setText("Guardar Fotografia ");
     btnIniciar.setText("Iniciar   ");
        
        
    }

    public int getLargoCamara() {
        return largoCamara;
    }

    public void setLargoCamara(int largoCamara) {
        this.largoCamara = largoCamara;
    }

    public int getAnchoCamara() {
        return anchoCamara;
    }

    public void setAnchoCamara(int anchoCamara) {
        this.anchoCamara = anchoCamara;
    }

    public Dimension getDimension() {
        return dimension;
    }

    public void setDimension(Dimension dimension) {
        this.dimension = dimension;
    }

    public Dimension getDimension1() {
        return dimension1;
    }

    public void setDimension1(Dimension dimension1) {
        this.dimension1 = dimension1;
    }

    public Webcam getWebcam() {
        return webcam;
    }

    public void setWebcam(Webcam webcam) {
        this.webcam = webcam;
    }

    public WebcamPanel getWebcamPanel() {
        return webcamPanel;
    }

    public void setWebcamPanel(WebcamPanel webcamPanel) {
        this.webcamPanel = webcamPanel;
    }

    public BufferedImage getRuta() {
        return ruta;
    }

    public void setRuta(BufferedImage ruta) {
        this.ruta = ruta;
    }

    public int getContador() {
        return contador;
    }

    public void setContador(int contador) {
        this.contador = contador;
    }

    public JButton getBtnApagar() {
        return btnApagar;
    }

    public void setBtnApagar(JButton btnApagar) {
        this.btnApagar = btnApagar;
    }

    public JButton getBtnCapturarFoto() {
        return btnCapturarFoto;
    }

    public void setBtnCapturarFoto(JButton btnCapturarFoto) {
        this.btnCapturarFoto = btnCapturarFoto;
    }

    public JButton getBtnGuardarFoto() {
        return btnGuardarFoto;
    }

    public void setBtnGuardarFoto(JButton btnGuardarFoto) {
        this.btnGuardarFoto = btnGuardarFoto;
    }

    public JButton getBtnIniciar() {
        return btnIniciar;
    }

    public void setBtnIniciar(JButton btnIniciar) {
        this.btnIniciar = btnIniciar;
    }

    public JLabel getjLabel2() {
        return jLabel2;
    }

    public void setjLabel2(JLabel jLabel2) {
        this.jLabel2 = jLabel2;
    }

    public JPanel getjPanel1() {
        return jPanel1;
    }

    public void setjPanel1(JPanel jPanel1) {
        this.jPanel1 = jPanel1;
    }

    public JPanel getjPanel2() {
        return jPanel2;
    }

    public void setjPanel2(JPanel jPanel2) {
        this.jPanel2 = jPanel2;
    }

    public JLabel getLblFotoTomada() {
        return lblFotoTomada;
    }

    public void setLblFotoTomada(JLabel lblFotoTomada) {
        this.lblFotoTomada = lblFotoTomada;
    }

    public JLabel getLblNombreCamara() {
        return lblNombreCamara;
    }

    public void setLblNombreCamara(JLabel lblNombreCamara) {
        this.lblNombreCamara = lblNombreCamara;
    }

    public JPanel getPnlCamara() {
        return pnlCamara;
    }

    public void setPnlCamara(JPanel pnlCamara) {
        this.pnlCamara = pnlCamara;
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        btnIniciar = new javax.swing.JButton();
        btnApagar = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        btnCapturarFoto = new javax.swing.JButton();
        btnGuardarFoto = new javax.swing.JButton();
        AtrasButton = new javax.swing.JButton();
        pnlCamara = new javax.swing.JPanel();
        lblFotoTomada = new javax.swing.JLabel();
        lblNombreCamara = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setResizable(false);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 153)), "Opciones", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), new java.awt.Color(0, 102, 153))); // NOI18N

        btnIniciar.setBackground(new java.awt.Color(255, 255, 255));
        btnIniciar.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        btnIniciar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/camara encedida.png"))); // NOI18N
        btnIniciar.setText("INICIAR");
        btnIniciar.setBorder(null);
        btnIniciar.setBorderPainted(false);
        btnIniciar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnIniciar.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnIniciar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnIniciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIniciarActionPerformed(evt);
            }
        });

        btnApagar.setBackground(new java.awt.Color(255, 255, 255));
        btnApagar.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        btnApagar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/CAMARA APAGADA.png"))); // NOI18N
        btnApagar.setText("APAGAR");
        btnApagar.setBorder(null);
        btnApagar.setBorderPainted(false);
        btnApagar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnApagar.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnApagar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnApagar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnApagarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnApagar, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnIniciar, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(14, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(btnIniciar)
                .addGap(83, 83, 83)
                .addComponent(btnApagar)
                .addContainerGap(64, Short.MAX_VALUE))
        );

        jPanel3.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, -1, -1));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 153)));

        btnCapturarFoto.setBackground(new java.awt.Color(255, 255, 255));
        btnCapturarFoto.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        btnCapturarFoto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/otro foto.png"))); // NOI18N
        btnCapturarFoto.setText("TOMAR FOTO");
        btnCapturarFoto.setBorder(null);
        btnCapturarFoto.setBorderPainted(false);
        btnCapturarFoto.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnCapturarFoto.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnCapturarFoto.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnCapturarFoto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCapturarFotoActionPerformed(evt);
            }
        });

        btnGuardarFoto.setBackground(new java.awt.Color(255, 255, 255));
        btnGuardarFoto.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        btnGuardarFoto.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Guaradar foto.png"))); // NOI18N
        btnGuardarFoto.setText("GUARDAR");
        btnGuardarFoto.setBorder(null);
        btnGuardarFoto.setBorderPainted(false);
        btnGuardarFoto.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnGuardarFoto.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnGuardarFoto.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnGuardarFoto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarFotoActionPerformed(evt);
            }
        });

        AtrasButton.setBackground(new java.awt.Color(255, 255, 255));
        AtrasButton.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        AtrasButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/flecha.png"))); // NOI18N
        AtrasButton.setText("ATRAS");
        AtrasButton.setBorder(null);
        AtrasButton.setBorderPainted(false);
        AtrasButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        AtrasButton.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        AtrasButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        AtrasButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AtrasButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(AtrasButton, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(146, 146, 146)
                .addComponent(btnCapturarFoto, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 267, Short.MAX_VALUE)
                .addComponent(btnGuardarFoto, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(113, 113, 113))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnGuardarFoto)
                    .addComponent(AtrasButton)
                    .addComponent(btnCapturarFoto))
                .addContainerGap(23, Short.MAX_VALUE))
        );

        jPanel3.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 460, 890, -1));

        pnlCamara.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout pnlCamaraLayout = new javax.swing.GroupLayout(pnlCamara);
        pnlCamara.setLayout(pnlCamaraLayout);
        pnlCamaraLayout.setHorizontalGroup(
            pnlCamaraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 360, Short.MAX_VALUE)
        );
        pnlCamaraLayout.setVerticalGroup(
            pnlCamaraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 370, Short.MAX_VALUE)
        );

        jPanel3.add(pnlCamara, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 50, 360, 370));

        lblFotoTomada.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 102, 153)));
        jPanel3.add(lblFotoTomada, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 110, 341, 310));

        lblNombreCamara.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblNombreCamara.setText("-");
        lblNombreCamara.setFont(new java.awt.Font("Arial", 0, 8)); // NOI18N
        jPanel3.add(lblNombreCamara, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 110, 140, -1));

        jLabel2.setText("Camara en uso");
        jLabel2.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 102, 153));
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 80, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 940, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 687, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnIniciarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIniciarActionPerformed
      textoBotonesCuandoCargaCamara();
      Thread hilo=new Thread(){
         
          @Override
          public void run(){
             webcamPanel.start();
             prenderBotones();
             textoBotonesCuandoCargoCamara();
          }
      };
      
      hilo.setDaemon(true);
      hilo.start();
      btnIniciar.setEnabled(false);
    }//GEN-LAST:event_btnIniciarActionPerformed

    private void btnApagarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnApagarActionPerformed
       webcamPanel.stop();
       apagarBotones();
       btnIniciar.setEnabled(true);
        
        
        
        
    }//GEN-LAST:event_btnApagarActionPerformed

    private void btnGuardarFotoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarFotoActionPerformed

    }//GEN-LAST:event_btnGuardarFotoActionPerformed

    private void btnCapturarFotoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCapturarFotoActionPerformed
      
        btnCapturarFoto.setText("Tomar Otra Foto");
        btnGuardarFoto.setEnabled(true);
        
        ImageIcon foto;
        foto= new ImageIcon(webcam.getImage());
        Icon inconoFoto=new ImageIcon(foto.getImage().getScaledInstance(lblFotoTomada.getWidth(), lblFotoTomada.getHeight(),Image.SCALE_SMOOTH));
        lblFotoTomada.setIcon(inconoFoto);
        
        
        ruta= webcam.getImage();
    }//GEN-LAST:event_btnCapturarFotoActionPerformed

    private void AtrasButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AtrasButtonActionPerformed
        // TODO add your handling code here:
       
        
    }//GEN-LAST:event_AtrasButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegistroQuimioterapia.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegistroQuimioterapia.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegistroQuimioterapia.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegistroQuimioterapia.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegistroQuimioterapia().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AtrasButton;
    private javax.swing.JButton btnApagar;
    private javax.swing.JButton btnCapturarFoto;
    private javax.swing.JButton btnGuardarFoto;
    private javax.swing.JButton btnIniciar;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel lblFotoTomada;
    private javax.swing.JLabel lblNombreCamara;
    private javax.swing.JPanel pnlCamara;
    // End of variables declaration//GEN-END:variables

    private void setLocationRelativeto(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
