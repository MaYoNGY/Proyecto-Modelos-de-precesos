/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto;

import proyecto.controlador.ControlAdmin;
import proyecto.controlador.ControlEnfermero;
import proyecto.controlador.ControlMedico;
import proyecto.controlador.Controlador;
import proyecto.login.Login;
import proyecto.registro.DAO;
import proyecto.vista.AdmiPrincipal;
import proyecto.vista.EnfermeroPrincipal;
import proyecto.vista.EnfermeroSignosV;
import proyecto.vista.EnfermeroDarMedicamentos;
import proyecto.vista.EscribirReceta;
import proyecto.vista.MedicoPrincipal;
import proyecto.vista.MostrarRQV;
import proyecto.vista.MostrarRecetasV;
import proyecto.vista.MostrarRegistroAdmin;
import proyecto.vista.MostrarSignosVitales;
import proyecto.vista.Principal;
import proyecto.vista.ProgramarSuministro;
import proyecto.vista.RegistroEmpleado;
import proyecto.vista.RegistroPaciente;
import proyecto.vista.RegistroQuimioterapia;


/**
 *
 * @author Windows
 */
public class Proyecto {
    /**
     * @param args the command line arguments
     */
     public static void main(String[] args) {
        //RegistroQuimioterapia.main(args);
        DAO.conectar();
        
        Principal principal = new Principal();

        AdmiPrincipal admin =new AdmiPrincipal();
        RegistroEmpleado empleado=new RegistroEmpleado();
        RegistroPaciente paciente=new RegistroPaciente();
        RegistroQuimioterapia camara=new RegistroQuimioterapia();
        MostrarRegistroAdmin mostrar=new MostrarRegistroAdmin();

        MedicoPrincipal medico =new MedicoPrincipal();
        EscribirReceta receta =new EscribirReceta();
        ProgramarSuministro suministro =new ProgramarSuministro();
        MostrarRecetasV mostrarR =new MostrarRecetasV();
        MostrarRQV mostrarQ =new MostrarRQV();
        MostrarSignosVitales mostrarS =new MostrarSignosVitales();

        EnfermeroPrincipal enfermero =new EnfermeroPrincipal();
        EnfermeroSignosV signosV =new EnfermeroSignosV();
        EnfermeroDarMedicamentos dar=new EnfermeroDarMedicamentos();

        Login login = new Login("", "", principal, admin, medico, enfermero);
        ControlAdmin controlA=new ControlAdmin(login,admin,empleado,paciente,camara,mostrar);
        ControlMedico controlM =new ControlMedico(medico,receta,suministro,mostrarR,mostrarS,mostrarQ);
        ControlEnfermero controlE =new ControlEnfermero(enfermero,signosV,dar);
        Controlador controlador = new Controlador(login, principal, admin, medico, enfermero);
    }
    
}
