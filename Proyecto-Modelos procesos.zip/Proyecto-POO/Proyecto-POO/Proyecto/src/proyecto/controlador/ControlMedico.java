/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.controlador;

import com.github.lgooddatepicker.optionalusertools.DateChangeListener;
import com.github.lgooddatepicker.optionalusertools.TimeChangeListener;
import com.github.lgooddatepicker.zinternaltools.DateChangeEvent;
import com.github.lgooddatepicker.zinternaltools.TimeChangeEvent;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.time.Instant;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import proyecto.Modelo.Enfermero;
import proyecto.Modelo.Fecha;
import proyecto.Modelo.Medicamento;
import proyecto.Modelo.Medico;
import proyecto.Modelo.Paciente;
import proyecto.Modelo.Receta;
import proyecto.Modelo.Suministro;
import proyecto.Modelo.Terminal;
import proyecto.login.Login;
import proyecto.registro.EmpleadosDAO;
import proyecto.registro.PacientesDAO;
import proyecto.registro.RecetasDAO;
import proyecto.registro.SuministrosDAO;
import proyecto.vista.EscribirReceta;
import proyecto.vista.MedicoPrincipal;
import proyecto.vista.MostrarRQV;
import proyecto.vista.MostrarRecetasV;
import proyecto.vista.MostrarSignosVitales;
import proyecto.vista.ProgramarSuministro;

/**
 *
 * @author USER
 */
public class ControlMedico implements ActionListener, KeyListener, DateChangeListener, TimeChangeListener {
    private MedicoPrincipal medicoPrincipal;
    private EscribirReceta escribirReceta;
    private ProgramarSuministro programarSuministro;
    private MostrarRecetasV mostrarReceta;
    private MostrarSignosVitales mostrarSV;
    private Receta recetaSuministro;
    private MostrarRQV mostrarRQ;

    public ControlMedico(MedicoPrincipal medicoPrincipal, EscribirReceta escribirReceta, ProgramarSuministro programarSuministro, MostrarRecetasV mostrarReceta, MostrarSignosVitales mostrarSV, MostrarRQV mostrarRQ) {
        this.medicoPrincipal = medicoPrincipal;
        this.escribirReceta = escribirReceta;
        this.programarSuministro = programarSuministro;
        this.mostrarReceta = mostrarReceta;
        this.mostrarSV = mostrarSV;
        this.mostrarRQ = mostrarRQ;
        
        escribirReceta.getAtrasButton().addActionListener(this);
        escribirReceta.getGuardarButton().addActionListener(this);
        escribirReceta.getNuevoButton().addActionListener(this);
        escribirReceta.getPlanificarSuministroButton().addActionListener(this);
        escribirReceta.getPacienteComboBox().addActionListener(this);
        escribirReceta.getIndicacionesTextArea().addKeyListener(this);
        escribirReceta.getDiagnosticoTextArea().addKeyListener(this);
        
        medicoPrincipal.getCerrarSesionButton().addActionListener(this);
        medicoPrincipal.getRecetasButton().addActionListener(this);
        medicoPrincipal.getRecetasTMostrarButton().addActionListener(this);
        medicoPrincipal.getRecetasQMostrarButton().addActionListener(this);
        medicoPrincipal.getSignosVitalesButton().addActionListener(this);
        
        mostrarReceta.getAtrasButton().addActionListener(this);
        
        mostrarRQ.getAtrasButton().addActionListener(this);
        mostrarRQ.getPacientesComboBox().addActionListener(this);
        
        mostrarSV.getAtrasButton().addActionListener(this);
        mostrarSV.getPacientesComboBox().addActionListener(this);
        
        
        programarSuministro.getAtrasButton().addActionListener(this);
        programarSuministro.getGuardarButton().addActionListener(this);
        programarSuministro.getNuevoButton().addActionListener(this);
        programarSuministro.getMedicamentoTextField().addKeyListener(this);
        programarSuministro.getPresentacionComboBox().addActionListener(this);
        programarSuministro.getEnfermeroComboBox().addActionListener(this);
        programarSuministro.getDosisTextField().addKeyListener(this);
        programarSuministro.getCalendario().addDateChangeListener(this);
        programarSuministro.getHora().addTimeChangeListener(this);
    }

    private boolean escribirRecetaVacio() {
        String diagnostico = escribirReceta.getDiagnosticoTextArea().getText();
        String indicaciones = escribirReceta.getIndicacionesTextArea().getText();
        int pacienteIndex = escribirReceta.getPacienteComboBox().getSelectedIndex();
        
        return (diagnostico.equals("") || indicaciones.equals("") || pacienteIndex == 0);
    }
    
    private boolean programarSuministroVacio(){
        String medicamento = programarSuministro.getMedicamentoTextField().getText();
        int enfermero = programarSuministro.getEnfermeroComboBox().getSelectedIndex();
        int presentacion = programarSuministro.getPresentacionComboBox().getSelectedIndex();
        String dosis = programarSuministro.getDosisTextField().getText();
        String fecha = programarSuministro.getCalendario().getDateStringOrEmptyString();
        String hora = programarSuministro.getHora().getTimeStringOrEmptyString();
        
        return (medicamento.equals("") || presentacion == 0 || enfermero == 0 || dosis.equals("") || fecha.equals("") || hora.equals(""));
    }
    
    @Override
    public void actionPerformed(ActionEvent ae) {
        // MÉDICO PRINCIPAL
        // ----------------------------------------------------------------------------------------
        if (ae.getSource().equals(medicoPrincipal.getRecetasButton())) {
            //Entrar a escribir receta        
            escribirReceta.getPacienteComboBox().removeAllItems();
            escribirReceta.getPacienteComboBox().addItem("-Seleccione-");
            
            for (Terminal terminal : PacientesDAO.getTerminales())
                escribirReceta.getPacienteComboBox().addItem(terminal.getCedula() + " - " + terminal.getNombre());
            
            medicoPrincipal.setVisible(false);
            escribirReceta.setVisible(true);
            escribirReceta.getGuardarButton().setEnabled(false);
            escribirReceta.getPlanificarSuministroButton().setEnabled(false);
        }
        
        // CREAR RECETA
        // ----------------------------------------------------------------------------------------
        if (ae.getSource().equals(escribirReceta.getPlanificarSuministroButton())) {
            escribirReceta.dispose();
            programarSuministro.show();
            programarSuministro.getGuardarButton().setEnabled(false);
            
            programarSuministro.getEnfermeroComboBox().removeAllItems();
            programarSuministro.getEnfermeroComboBox().addItem("-Seleccione-");
            for (Enfermero enfermero :EmpleadosDAO.getEnfermeros())
                programarSuministro.getEnfermeroComboBox().addItem(enfermero.getCedula() + " - " + enfermero.getNombre());
            
            
        }
        
        if (ae.getSource().equals(escribirReceta.getGuardarButton())) {
            // guardar paciente- escribir codigo
            
            String diagnostico = escribirReceta.getDiagnosticoTextArea().getText();
            String indicaciones = escribirReceta.getIndicacionesTextArea().getText();
            Medico medico = EmpleadosDAO.findMedico(Login.getUsuario());
            
            Paciente paciente = null;
           
                    
            int pacienteIndex = escribirReceta.getPacienteComboBox().getSelectedIndex() -1;
            
            if (pacienteIndex >= 0)
                paciente = PacientesDAO.getTerminales().get(pacienteIndex);
            
            if (medico != null) {
                int id;
                
                if (RecetasDAO.getRecetas().isEmpty())
                    id = 1;
                else
                    id = RecetasDAO.getRecetas().get(RecetasDAO.getRecetas().size() - 1).getId() + 1;
                
                
                Receta receta = new Receta(id, medico, paciente, new ArrayList(), diagnostico, indicaciones);
                recetaSuministro = receta;
                RecetasDAO.add(receta);
                System.out.println(receta.toString());
                
                escribirReceta.getPacienteComboBox().setEnabled(false);
                escribirReceta.getDiagnosticoTextArea().setEditable(false);
                escribirReceta.getIndicacionesTextArea().setEditable(false);
                escribirReceta.getPlanificarSuministroButton().setEnabled(false);
                escribirReceta.getGuardarButton().setEnabled(false);
                escribirReceta.getPlanificarSuministroButton().setEnabled(true);
                
                JOptionPane.showMessageDialog(escribirReceta, "Receta registrada con éxito.");
            } else {
                if (medico == null)
                    JOptionPane.showMessageDialog(escribirReceta, "Error : médico no existe.");
            } 
        }
        
        if (ae.getSource().equals(escribirReceta.getNuevoButton())) {
            // nuevo paciente
            escribirReceta.getPacienteComboBox().setEnabled(true);
            escribirReceta.getPacienteComboBox().setSelectedItem("-Seleccione-");
            escribirReceta.getDiagnosticoTextArea().setEditable(true);
            escribirReceta.getDiagnosticoTextArea().setText("");
            escribirReceta.getIndicacionesTextArea().setEditable(true);
            escribirReceta.getIndicacionesTextArea().setText("");
            escribirReceta.getPlanificarSuministroButton().setEnabled(false);
            
        }
        
        if (ae.getSource().equals(escribirReceta.getAtrasButton())) {
            escribirReceta.getPacienteComboBox().setEnabled(true);
            escribirReceta.getPacienteComboBox().setSelectedItem("-Seleccione-");
            escribirReceta.getDiagnosticoTextArea().setEditable(true);
            escribirReceta.getDiagnosticoTextArea().setText("");
            escribirReceta.getIndicacionesTextArea().setEditable(true);
            escribirReceta.getIndicacionesTextArea().setText("");
            escribirReceta.getPlanificarSuministroButton().setEnabled(true);
            //cerrar escribir receta
            escribirReceta.dispose();
            medicoPrincipal.show();
            
        }
        
        // CREAR SUMINISTRO
        // ----------------------------------------------------------------------------------------
        if (ae.getSource().equals(programarSuministro.getGuardarButton())) {
            //guardar suministro- escribir codigo
            programarSuministro.getMedicamentoTextField().setEditable(false);
            programarSuministro.getEnfermeroComboBox().setEnabled(false);
            programarSuministro.getPresentacionComboBox().setEnabled(false);
            programarSuministro.getDosisTextField().setEditable(false);
            programarSuministro.getCalendario().setEnabled(false);
            programarSuministro.getHora().setEnabled(false);
            programarSuministro.getGuardarButton().setEnabled(false);
            
            Date date = Date.from(Instant.from(programarSuministro.getCalendario().getDate().atStartOfDay(ZoneId.systemDefault())));
            long hour = programarSuministro.getHora().getTime().getHour() * 3600000 + programarSuministro.getHora().getTime().getMinute() * 60000;
            
            Fecha fecha = new Fecha(date.getTime() + hour);
            Enfermero enfermero = EmpleadosDAO.getEnfermeros().get(programarSuministro.getEnfermeroComboBox().getSelectedIndex() - 1);
            
            String medicamentoNombre = programarSuministro.getMedicamentoTextField().getText();
            String medicamentoPresentacion = programarSuministro.getPresentacionComboBox().getSelectedItem().toString();
            String medicamentoDosis = programarSuministro.getDosisTextField().getText();
            
            Suministro suministro = new Suministro(SuministrosDAO.id(), fecha, recetaSuministro, enfermero, new Medicamento(medicamentoNombre, medicamentoPresentacion, medicamentoDosis));

            SuministrosDAO.add(suministro);
            JOptionPane.showMessageDialog(programarSuministro, "Suministro registrado con éxito.");
           
        }
        
        if (ae.getSource().equals(programarSuministro.getNuevoButton())) {
            //nuevo suministro
            programarSuministro.getMedicamentoTextField().setEditable(true);
            programarSuministro.getMedicamentoTextField().setText("");
            programarSuministro.getEnfermeroComboBox().setEnabled(true);
            programarSuministro.getEnfermeroComboBox().setSelectedItem("-Seleccione-");
            programarSuministro.getPresentacionComboBox().setEnabled(true);
            programarSuministro.getPresentacionComboBox().setSelectedItem("-Seleccione-");
            programarSuministro.getDosisTextField().setEditable(true);
            programarSuministro.getDosisTextField().setText("");
            programarSuministro.getCalendario().setEnabled(true);
            programarSuministro.getCalendario().setText("");
            programarSuministro.getHora().setEnabled(true);
            programarSuministro.getHora().setText("");    
        }
        
        if (ae.getSource().equals(programarSuministro.getAtrasButton())) {
            programarSuministro.getMedicamentoTextField().setEditable(true);
            programarSuministro.getMedicamentoTextField().setText("");
            programarSuministro.getEnfermeroComboBox().setEnabled(true);
            programarSuministro.getEnfermeroComboBox().setSelectedItem("-Seleccione-");
            programarSuministro.getPresentacionComboBox().setEnabled(true);
            programarSuministro.getPresentacionComboBox().setSelectedItem("-Seleccione-");
            programarSuministro.getDosisTextField().setEditable(true);
            programarSuministro.getDosisTextField().setText("");
            programarSuministro.getCalendario().setEnabled(true);
            programarSuministro.getCalendario().setText("");
            programarSuministro.getHora().setEnabled(true);
            programarSuministro.getHora().setText("");
            //cerrar suministro
            programarSuministro.dispose();
            escribirReceta.show();
            
        }
        //MOSTRAR RECETA Terminal
        //----------------------------------------------------------------------------------------
        if(ae.getSource().equals(medicoPrincipal.getRecetasTMostrarButton())){
            DefaultTableModel  modelo=new DefaultTableModel();
            
            medicoPrincipal.dispose();
            mostrarReceta.show();
            mostrarReceta.getMostrarTable().setEnabled(false);
            modelo.addColumn("ID");
                modelo.addColumn("Fecha");
                modelo.addColumn("Cedula_Medico");
                modelo.addColumn("Cedula_Paciente");
                modelo.addColumn("Diagnostico");
                modelo.addColumn("Indicaciones");
                for(int i = 0; i < RecetasDAO.getRecetas().size(); i++){

                    Object[] fila = {
                        RecetasDAO.getRecetas().get(i).getId(),
                        RecetasDAO.getRecetas().get(i).getFecha().fechaString(),
                        RecetasDAO.getRecetas().get(i).getMedico().getCedula(),
                        RecetasDAO.getRecetas().get(i).getPaciente().getCedula(),
                        RecetasDAO.getRecetas().get(i).getDiagnostico(),
                        RecetasDAO.getRecetas().get(i).getIndicaciones()  
                    };
                    
                    modelo.addRow(fila);
                }
            mostrarReceta.getMostrarTable().setModel(modelo); 
        } 
        
        if(ae.getSource().equals(mostrarReceta.getAtrasButton())){
            
            mostrarReceta.dispose();
            medicoPrincipal.show();
            
        }
        
        //Mostrar Receta Quimio
        //--------------------------------------------------------------------------------------
        if(ae.getSource().equals(medicoPrincipal.getRecetasQMostrarButton())){
            medicoPrincipal.dispose();
            mostrarRQ.show();
            mostrarRQ.getPacientesComboBox().removeAllItems();
            mostrarRQ.getPacientesComboBox().addItem("-Seleccione-");
            for(Paciente paciente: PacientesDAO.getQuimioterapias())
                mostrarRQ.getPacientesComboBox().addItem(paciente.getCedula());
        }
        
        if(ae.getSource().equals(mostrarRQ.getAtrasButton())) {
            medicoPrincipal.show();
            mostrarRQ.dispose();
        }
        
        if(ae.getSource().equals(mostrarRQ.getPacientesComboBox()) ){
                   
            String cedula = (String) mostrarRQ.getPacientesComboBox().getSelectedItem();
            
            ImageIcon imageIcon = new ImageIcon("RecetaPacientesQuimioterapia\\"+cedula+".jpg");
            ImageIcon icon = new ImageIcon(imageIcon.getImage().getScaledInstance(mostrarRQ.getFotoLabel().getWidth(),mostrarRQ.getFotoLabel().getHeight(), Image.SCALE_DEFAULT));
            mostrarRQ.getFotoLabel().setIcon(icon);
            
            
        }
        
        
        //Mostrar SignosVitales
        //--------------------------------------------------------------------------------------
        if(ae.getSource().equals(medicoPrincipal.getSignosVitalesButton())){
            medicoPrincipal.dispose();
            mostrarSV.show();
            mostrarSV.getPacientesComboBox().removeAllItems();
            mostrarSV.getPacientesComboBox().addItem("-Seleccione-");
            for(Paciente paciente:PacientesDAO.getPacientes())
            mostrarSV.getPacientesComboBox().addItem(paciente.getCedula());
        }
        
        if(ae.getSource().equals(mostrarSV.getAtrasButton())){
            medicoPrincipal.show();
            mostrarSV.dispose();
        }
        
        if(ae.getSource().equals(mostrarSV.getPacientesComboBox())){
            String mostrar = (String) mostrarSV.getPacientesComboBox().getSelectedItem();
 
            for (int i = 0; i < PacientesDAO.getPacientes().size(); i++) {
                if(PacientesDAO.getPacientes().get(i).getCedula().equals(mostrar)){
                    String frecuencia = Integer.toString(PacientesDAO.getPacientes().get(i).getSignosVitales().getFrecuenciaCardiaca());
                    mostrarSV.getFrecuenciaLabel().setText(frecuencia);
                    String presion = Integer.toString(PacientesDAO.getPacientes().get(i).getSignosVitales().getPresionArterial());
                    mostrarSV.getPresionLabel().setText(presion);
                    String talla =  Integer.toString(PacientesDAO.getPacientes().get(i).getSignosVitales().getTalla());
                    mostrarSV.getTallaLabel().setText(talla);
                    String peso = Integer.toString(PacientesDAO.getPacientes().get(i).getSignosVitales().getPeso());
                    mostrarSV.getPesoLabel().setText(peso);
                    String temperatura = String.valueOf(PacientesDAO.getPacientes().get(i).getSignosVitales().getTemperatura());
                    mostrarSV.getTemperaturaLabel().setText(temperatura);
                    String fecha = String.valueOf(PacientesDAO.getPacientes().get(i).getSignosVitales().getFecha().fechaString());
                    mostrarSV.getFechaLabel().setText(fecha);
                }
            }
       
        }
        
        
        // VALIDACIONES
        // ----------------------------------------------------------------------------------------       
        if (ae.getSource().equals(escribirReceta.getPacienteComboBox())) {
            escribirReceta.getGuardarButton().setEnabled(!escribirRecetaVacio());   
        }
        
        if (ae.getSource().equals(programarSuministro.getEnfermeroComboBox())) {
            programarSuministro.getGuardarButton().setEnabled(!programarSuministroVacio());
        }
        if (ae.getSource().equals(programarSuministro.getPresentacionComboBox())) {
            programarSuministro.getGuardarButton().setEnabled(!programarSuministroVacio());
        }
        
    }

    @Override
    public void keyTyped(KeyEvent ke) {
    }

    @Override
    public void keyPressed(KeyEvent ke) {
    }

    @Override
    public void keyReleased(KeyEvent ke) {
        Object obj = ke.getSource();
        
        if (
            obj.equals(escribirReceta.getDiagnosticoTextArea())
            || obj.equals(escribirReceta.getIndicacionesTextArea())
        )
            escribirReceta.getGuardarButton().setEnabled(!escribirRecetaVacio());
           
        if(
            obj.equals(programarSuministro.getMedicamentoTextField())
            || obj.equals(programarSuministro.getDosisTextField())
            || obj.equals(programarSuministro.getCalendario())
            || obj.equals(programarSuministro.getHora())
        ) 
            programarSuministro.getGuardarButton().setEnabled(!programarSuministroVacio());
    }

    @Override
    public void dateChanged(DateChangeEvent dce) {
        if (dce.getSource().equals(programarSuministro.getCalendario()))
            programarSuministro.getGuardarButton().setEnabled(!programarSuministroVacio());
    }

    @Override
    public void timeChanged(TimeChangeEvent tce) {
        if (tce.getSource().equals(programarSuministro.getHora()))
            programarSuministro.getGuardarButton().setEnabled(!programarSuministroVacio());
    }
    
}
