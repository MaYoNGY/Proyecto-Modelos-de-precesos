/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import proyecto.Modelo.Educacion;
import proyecto.Modelo.Empleado;
import proyecto.Modelo.Enfermero;
import proyecto.Modelo.Medico;
import proyecto.Modelo.Paciente;
import proyecto.Modelo.Quimioterapia;
import proyecto.Modelo.Terminal;
import proyecto.login.Login;
import proyecto.registro.EmpleadosDAO;
import proyecto.registro.PacientesDAO;
import proyecto.vista.AdmiPrincipal;
import proyecto.vista.MostrarRegistroAdmin;

import proyecto.vista.RegistroEmpleado;
import proyecto.vista.RegistroPaciente;
import proyecto.vista.RegistroQuimioterapia;

/**
 *
 * @author USER
 */
public class ControlAdmin implements ActionListener, KeyListener{
    private Login login;
    private AdmiPrincipal adminPrincipal;
    private RegistroEmpleado registroEmpleado;
    private RegistroPaciente registroPaciente;
    private RegistroQuimioterapia registroQuimioterapia;
    private MostrarRegistroAdmin mostrarRe;
    

    public ControlAdmin(Login login, AdmiPrincipal adminPrincipal, RegistroEmpleado registroEmpleado, RegistroPaciente registroPaciente, RegistroQuimioterapia registroQuimioterapia, MostrarRegistroAdmin mostrarRe) {
        this.login = login;
        this.adminPrincipal = adminPrincipal;
        this.registroEmpleado = registroEmpleado;
        this.registroPaciente = registroPaciente;
        this.registroQuimioterapia = registroQuimioterapia;
        this.mostrarRe = mostrarRe;
        
        adminPrincipal.getEmpleadosButton().addActionListener(this);
        adminPrincipal.getPacientesButton().addActionListener(this);
        adminPrincipal.getCerrarSesionButton().addActionListener(this);        
        adminPrincipal.getMostrarButton().addActionListener(this);
        
        registroEmpleado.getAtrasButton().addActionListener(this);
        registroEmpleado.getNuevoButton().addActionListener(this);
        registroEmpleado.getGuardarButton().addActionListener(this);
        registroEmpleado.getCargoLaboralComboBox().addActionListener(this);
        registroEmpleado.getTituloComboBox().addActionListener(this);

        registroEmpleado.getCedulaTextField().addKeyListener(this);
        registroEmpleado.getNomreProfesionalTextField().addKeyListener(this);
        registroEmpleado.getNumeroRegistroTextField().addKeyListener(this);
        
        registroPaciente.getAtrasButton().addActionListener(this);
        registroPaciente.getGuardarButton().addActionListener(this);
        registroPaciente.getNuevoButton().addActionListener(this);
        registroPaciente.getTipoPacienteComboBox().addActionListener(this);
        registroPaciente.getCedulaTextField().addKeyListener(this);
        registroPaciente.getNombrePacienteTextField().addKeyListener(this);
        
        registroQuimioterapia.getAtrasButton().addActionListener(this);  
        mostrarRe.getAtrasButton().addActionListener(this);
        mostrarRe.getReportesOpcComboBox().addActionListener(this);
        registroQuimioterapia.getBtnGuardarFoto().addActionListener(this);
    }
    
    private boolean registroEmpleadoVacio() {
        String cedula = registroEmpleado.getCedulaTextField().getText();
        String nombre = registroEmpleado.getNomreProfesionalTextField().getText();
        String educacionNumero = registroEmpleado.getNumeroRegistroTextField().getText();       
        int cargoIndex = registroEmpleado.getCargoLaboralComboBox().getSelectedIndex();
        int educacionIndex = registroEmpleado.getTituloComboBox().getSelectedIndex();

        return (cedula.equals("") || nombre.equals("") || educacionNumero.equals("") || cargoIndex == 0 || educacionIndex == 0);
    }
    
    private boolean registroPacienteVacio() {
        String cedula = registroPaciente.getCedulaTextField().getText();
        String nombre = registroPaciente.getNombrePacienteTextField().getText();
        int tipoPaciente = registroPaciente.getTipoPacienteComboBox().getSelectedIndex();

        return (cedula.equals("") || nombre.equals("") || tipoPaciente == 0);
    }
    
    
    @Override
    @SuppressWarnings("empty-statement")
    public void actionPerformed(ActionEvent ae) {
        // ADMIN PRINCIPAL
        // ----------------------------------------------------------------------------------------
        if (ae.getSource().equals(adminPrincipal.getEmpleadosButton())) {
            //entrar Registro Empleado
            adminPrincipal.setVisible(false);
            registroEmpleado.setVisible(true);
            registroEmpleado.getGuardarButton().setEnabled(false);
        }
        
        if (ae.getSource().equals(adminPrincipal.getPacientesButton())) {
            //entrar registro Paciente
            adminPrincipal.setVisible(false);
            registroPaciente.setVisible(true);
            registroPaciente.getGuardarButton().setEnabled(false);
            registroPaciente.getTipoPacienteComboBox().setEnabled(false);
        }
        
        // REGISTRO EMPLEADO
        // ----------------------------------------------------------------------------------------
        if (ae.getSource().equals(registroEmpleado.getGuardarButton())) {
            //guardar registro-escribir codigo
            boolean repetido = false;
            String cedula = registroEmpleado.getCedulaTextField().getText();
            String nombre = registroEmpleado.getNomreProfesionalTextField().getText();
            String educacionTipo = registroEmpleado.getTituloComboBox().getSelectedItem().toString();
            String educacionNumero = registroEmpleado.getNumeroRegistroTextField().getText();
            
            int cargoIndex = registroEmpleado.getCargoLaboralComboBox().getSelectedIndex();
            
            for (Empleado empleado : EmpleadosDAO.getEmpleados())
                if (empleado.getCedula().equals(cedula))
                    repetido = true;
            
            if (cedula.matches("\\d{10}") && !repetido) {
                if (cargoIndex == 1) {
                    Educacion educacion = new Educacion(educacionTipo, educacionNumero);
                    Enfermero enfermero = new Enfermero(cedula, nombre, educacion);
                    EmpleadosDAO.add(enfermero);
                    JOptionPane.showMessageDialog(registroEmpleado,"Enfermero ingresado correctamente (cedula: " + enfermero.getCedula() + ")");
                }
                if (cargoIndex == 2) {
                    Educacion educacion = new Educacion(educacionTipo, educacionNumero);
                    Medico medico = new Medico(cedula, nombre, educacion);
                    EmpleadosDAO.add(medico);
                    JOptionPane.showMessageDialog(registroEmpleado,"Mèdico ingresado correctamente (cedula: " + medico.getCedula() + ")");
                }
                
                registroEmpleado.getNomreProfesionalTextField().setEditable(false);
                registroEmpleado.getCedulaTextField().setEditable(false);
                registroEmpleado.getTituloComboBox().setEnabled(false);
                registroEmpleado.getNumeroRegistroTextField().setEditable(false);
                registroEmpleado.getCargoLaboralComboBox().setEnabled(false);
                registroEmpleado.getGuardarButton().setEnabled(false);
            } 
            else {
                if (!cedula.matches("\\d{10}"))
                    JOptionPane.showMessageDialog(registroEmpleado,"cedula no válida");
                if (repetido)
                    JOptionPane.showMessageDialog(registroEmpleado,"cedula: " + cedula + " ya existe");
            }
        }
        
        if (ae.getSource().equals(registroEmpleado.getNuevoButton())) {
            //nuevo registro
            registroEmpleado.getNomreProfesionalTextField().setEditable(true);
            registroEmpleado.getNomreProfesionalTextField().setText("");
            registroEmpleado.getCedulaTextField().setEditable(true);
            registroEmpleado.getCedulaTextField().setText("");
            registroEmpleado.getTituloComboBox().setEnabled(true);
            registroEmpleado.getTituloComboBox().setSelectedItem("-Seleccione-");
            registroEmpleado.getNumeroRegistroTextField().setEditable(true);
            registroEmpleado.getNumeroRegistroTextField().setText("");
            registroEmpleado.getCargoLaboralComboBox().setEnabled(true);
            registroEmpleado.getCargoLaboralComboBox().setSelectedItem("-Seleccione-");     
        }
        
        if (ae.getSource().equals(registroEmpleado.getAtrasButton())) {
            registroEmpleado.getNomreProfesionalTextField().setEditable(true);
            registroEmpleado.getNomreProfesionalTextField().setText("");
            registroEmpleado.getCedulaTextField().setEditable(true);
            registroEmpleado.getCedulaTextField().setText("");
            registroEmpleado.getTituloComboBox().setEnabled(true);
            registroEmpleado.getTituloComboBox().setSelectedItem("-Seleccione-");
            registroEmpleado.getNumeroRegistroTextField().setEditable(true);
            registroEmpleado.getNumeroRegistroTextField().setText("");
            registroEmpleado.getCargoLaboralComboBox().setEnabled(true);
            registroEmpleado.getCargoLaboralComboBox().setSelectedItem("-Seleccione-");
            //salir Registro Empleado
            registroEmpleado.dispose();
            adminPrincipal.show();   
        }

        if (ae.getSource().equals(registroEmpleado.getCargoLaboralComboBox())) {     
            int cargoIndex = registroEmpleado.getCargoLaboralComboBox().getSelectedIndex();
            
            if (cargoIndex == 0) {
                registroEmpleado.getTituloComboBox().removeAllItems();
                registroEmpleado.getTituloComboBox().addItem("-Seleccione-");
            }

            if (cargoIndex == 1) {                
                registroEmpleado.getTituloComboBox().removeAllItems();
                
                registroEmpleado.getTituloComboBox().addItem("-Seleccione-");
                registroEmpleado.getTituloComboBox().addItem("Enfermero/a registrado");
                registroEmpleado.getTituloComboBox().addItem("Enfermero/a Practicante");
                registroEmpleado.getTituloComboBox().addItem("Enfermero/a Especialista Clinico");
            }       
            if (cargoIndex == 2) {    
                registroEmpleado.getTituloComboBox().removeAllItems();
                
                registroEmpleado.getTituloComboBox().addItem("-Seleccione-");
                registroEmpleado.getTituloComboBox().addItem("Medico/a General");
                registroEmpleado.getTituloComboBox().addItem("Medico/a Especialista");
                registroEmpleado.getTituloComboBox().addItem("Medico/a Internista");
            }  
        } 
        
        // REGISTRO PACIENTE
        // ----------------------------------------------------------------------------------------
        if (ae.getSource().equals(registroPaciente.getGuardarButton())) {
            //guardar registro - escribir codigo
            boolean repetido = false;
            String cedula = registroPaciente.getCedulaTextField().getText();
            String nombre = registroPaciente.getNombrePacienteTextField().getText();
            
            for (Paciente paciente : PacientesDAO.getPacientes())
                if (paciente.getCedula().equals(cedula))
                    repetido = true;
            
            if (cedula.matches("\\d{10}") && !repetido) {
                if (registroPaciente.getTipoPacienteComboBox().getSelectedIndex() == 1) {
                    Quimioterapia quimioterapia = new Quimioterapia(cedula, nombre);
                    PacientesDAO.add(quimioterapia);
                    JOptionPane.showMessageDialog(registroPaciente,"Paciente paliativo ingresado correctamente (cedula: " + quimioterapia.getCedula() + ")");
                
                    registroQuimioterapia.show(); 

                }
                if (registroPaciente.getTipoPacienteComboBox().getSelectedIndex() == 2) {
                    Terminal terminal = new Terminal(cedula, nombre);
                    PacientesDAO.add(terminal);
                    JOptionPane.showMessageDialog(registroPaciente,"Paciente terminal ingresado correctamente (cedula: " + terminal.getCedula() + ")");
                }
                
                registroPaciente.getNombrePacienteTextField().setEditable(false);
                registroPaciente.getCedulaTextField().setEditable(false);
                registroPaciente.getTipoPacienteComboBox().setEnabled(false);
                registroPaciente.getGuardarButton().setEnabled(false);
            } 
            else {
                if (!cedula.matches("\\d{10}"))
                    JOptionPane.showMessageDialog(registroPaciente,"cedula no válida");
                if (repetido)
                    JOptionPane.showMessageDialog(registroPaciente,"cedula: " + cedula + " ya existe");
            }
        }
        
        if (ae.getSource().equals(registroPaciente.getNuevoButton())) {
            //nuevo registro
            registroPaciente.getNombrePacienteTextField().setEditable(true);
            registroPaciente.getNombrePacienteTextField().setText("");
            registroPaciente.getCedulaTextField().setEditable(true);
            registroPaciente.getCedulaTextField().setText("");
            registroPaciente.getTipoPacienteComboBox().setEnabled(true);
            registroPaciente.getTipoPacienteComboBox().setSelectedItem("-Seleccione-");  
        }
        
        if (ae.getSource().equals(registroPaciente.getAtrasButton())) {
            registroPaciente.getNombrePacienteTextField().setEditable(true);
            registroPaciente.getNombrePacienteTextField().setText("");
            registroPaciente.getCedulaTextField().setEditable(true);
            registroPaciente.getCedulaTextField().setText("");
            registroPaciente.getTipoPacienteComboBox().setEnabled(true);
            registroPaciente.getTipoPacienteComboBox().setSelectedItem("-Seleccione-");  
            //salir registro paciente
            registroPaciente.dispose();
            adminPrincipal.show();
 
        }
        
//        if (ae.getSource().equals(registroPaciente.getTipoPacienteComboBox())){
//            String selectedOption = registroPaciente.getTipoPacienteComboBox().getSelectedItem().toString();
//            if (selectedOption.equals("Cuidados Paliativos"))
//                // Abre una nueva ventana o realiza la acción que desees aquí
//                registroQuimioterapia.show(); 
//        }
        
        // CÁMARA QUIMIOTERAPIA
        // ----------------------------------------------------------------------------------------
        
        if (ae.getSource().equals(registroQuimioterapia.getAtrasButton())) {     
            registroQuimioterapia.dispose();
            registroPaciente.show();
        }
        
        if (ae.getSource().equals(registroQuimioterapia.getBtnGuardarFoto())) {     
            int pregunta =JOptionPane.showConfirmDialog(registroQuimioterapia,"¿Guardar Fotografia?","Pregunta",JOptionPane.YES_NO_OPTION,JOptionPane.INFORMATION_MESSAGE);
            String cedula = registroPaciente.getCedulaTextField().getText();
            
            if(pregunta==0){
                registroQuimioterapia.guardarImagen(cedula);

                registroQuimioterapia.getLblFotoTomada().setIcon(null);
                registroQuimioterapia.getBtnGuardarFoto().setEnabled(false);
                registroQuimioterapia.getBtnCapturarFoto().setText("Capturar Foto");
            }
        }
        
        // VALIDACIONES
        // ----------------------------------------------------------------------------------------
        
        if (
            ae.getSource().equals(registroEmpleado.getCargoLaboralComboBox())
            || ae.getSource().equals(registroEmpleado.getTituloComboBox())
        ) {
            registroEmpleado.getGuardarButton().setEnabled(!registroEmpleadoVacio());
        }
        
        if(ae.getSource().equals(registroPaciente.getTipoPacienteComboBox())){
            registroPaciente.getGuardarButton().setEnabled(!registroPacienteVacio());
        }
        
        if(ae.getSource().equals(adminPrincipal.getMostrarButton())){
            //mostrar ventana reporte
            adminPrincipal.dispose();
            mostrarRe.show(); 

        }
        
        if(ae.getSource().equals(mostrarRe.getAtrasButton())){
            //salir ventana reporte
            adminPrincipal.show();
            mostrarRe.dispose(); 
        }
        
        // -----------------------------------Reportes---------------------------------//
        if(ae.getSource().equals(mostrarRe.getReportesOpcComboBox())){
            
            DefaultTableModel  modelo=new DefaultTableModel();
            
            int reporteIndex = mostrarRe.getReportesOpcComboBox().getSelectedIndex();
            mostrarRe.getMostrarTable().setEnabled(false);
            if(reporteIndex == 1){
                
                modelo.addColumn("N°");
                modelo.addColumn("Numero cedula");
                modelo.addColumn("Nombre y Apellido");
                modelo.addColumn("Titulo");
                modelo.addColumn("N° Registro Titulo");
                for(int i = 0; i < EmpleadosDAO.getMedicos().size(); i++){
                    Object[] fila = {
                        i+1,
                        EmpleadosDAO.getMedicos().get(i).getCedula(),
                        EmpleadosDAO.getMedicos().get(i).getNombre(),
                        EmpleadosDAO.getMedicos().get(i).getEducacion().getTipo(),
                        EmpleadosDAO.getMedicos().get(i).getEducacion().getNumeroRegistro()};
                    modelo.addRow(fila);
                }
                mostrarRe.getMostrarTable().setModel(modelo);
                
            }
            
            if(reporteIndex == 2){
                
                modelo.addColumn("N°");
                modelo.addColumn("Numero de cedula");
                modelo.addColumn("Nombre y Apellido");
                modelo.addColumn("Titulo");
                modelo.addColumn("N° Registro Titulo");
                for(int i = 0; i < EmpleadosDAO.getEnfermeros().size(); i++){
                    Object[] fila = {
                        i+1,
                        EmpleadosDAO.getEnfermeros().get(i).getCedula(),
                        EmpleadosDAO.getEnfermeros().get(i).getNombre(),
                        EmpleadosDAO.getEnfermeros().get(i).getEducacion().getTipo(),
                        EmpleadosDAO.getEnfermeros().get(i).getEducacion().getNumeroRegistro()};
                    modelo.addRow(fila);
                }
                mostrarRe.getMostrarTable().setModel(modelo);
               
            }
            if(reporteIndex == 3){
                modelo.addColumn("N°");
                modelo.addColumn("Numero de cedula");
                modelo.addColumn("Nombre y Apellido");
                for(int i = 0; i < PacientesDAO.getQuimioterapias().size(); i++){
                    Object[] fila = {
                        i+1,
                        PacientesDAO.getQuimioterapias().get(i).getCedula(),
                        PacientesDAO.getQuimioterapias().get(i).getNombre()};
                    modelo.addRow(fila);
                }
                mostrarRe.getMostrarTable().setModel(modelo);
            }
            if(reporteIndex == 4){
                modelo.addColumn("N°");
                modelo.addColumn("Numero de cedula");
                modelo.addColumn("Nombre y Apellido");
                for(int i = 0; i < PacientesDAO.getTerminales().size(); i++){
                    Object[] fila = {
                        i+1,
                        PacientesDAO.getTerminales().get(i).getCedula(),
                        PacientesDAO.getTerminales().get(i).getNombre()};
                    modelo.addRow(fila);
                }
                mostrarRe.getMostrarTable().setModel(modelo);
            }
        }
    }    

    @Override
    public void keyTyped(KeyEvent ke) {
        char c = ke.getKeyChar();
        
        if (ke.getSource().equals(registroEmpleado.getCedulaTextField())) {
            if (!Character.isDigit(c) || registroEmpleado.getCedulaTextField().getText().length() >= 10)
                ke.consume(); // Limita a 10 caracteres numéricos
        }

        if (ke.getSource().equals(registroEmpleado.getNomreProfesionalTextField())) {
            if(!(Character.isAlphabetic(c) || c == ' ') || registroEmpleado.getNomreProfesionalTextField().getText().length() >= 50)
                ke.consume(); // Limita a 50 caracteres alfabéticos
        }
        
        if (ke.getSource().equals(registroEmpleado.getNumeroRegistroTextField())) {
            if(!Character.isDigit(c) || registroEmpleado.getNumeroRegistroTextField().getText().length() >= 14)
                ke.consume(); // Limita a 12 caracteres numéricos y dos guiones
            
            if (registroEmpleado.getNumeroRegistroTextField().getText().length() == 4 || registroEmpleado.getNumeroRegistroTextField().getText().length() == 7) {
                if (Character.isDigit(c))
                    registroEmpleado.getNumeroRegistroTextField().setText(registroEmpleado.getNumeroRegistroTextField().getText() + "-");
            }
        }

        if (ke.getSource().equals(registroPaciente.getCedulaTextField())) {
            if (!Character.isDigit(c) || registroPaciente.getCedulaTextField().getText().length() >= 10)
                ke.consume(); // Limita a 10 caracteres numéricos
        }

        if (ke.getSource().equals(registroPaciente.getNombrePacienteTextField())) {
            if(!(Character.isAlphabetic(c) || c == ' ') || registroPaciente.getNombrePacienteTextField().getText().length() >= 50)
                ke.consume(); // Limita a 50 caracteres alfabéticos
        }
        
    }

    @Override
    public void keyPressed(KeyEvent ke) {
    }

    @Override
    public void keyReleased(KeyEvent ke) {
        Object obj = ke.getSource();
        
        if (
            obj.equals(registroEmpleado.getCedulaTextField())
            || obj.equals(registroEmpleado.getNomreProfesionalTextField())
            || obj.equals(registroEmpleado.getNumeroRegistroTextField())
        )
            registroEmpleado.getGuardarButton().setEnabled(!registroEmpleadoVacio());
        
        if (
            obj.equals(registroPaciente.getCedulaTextField())
            || obj.equals(registroPaciente.getNombrePacienteTextField())
        ) {
            registroPaciente.getGuardarButton().setEnabled(!registroPacienteVacio());
            registroPaciente.getTipoPacienteComboBox().setEnabled(registroPaciente.getCedulaTextField().getText().matches("\\d{10}"));
        }
         
    }
}

        
        
 
        


   
        
        
        


   

    
    

