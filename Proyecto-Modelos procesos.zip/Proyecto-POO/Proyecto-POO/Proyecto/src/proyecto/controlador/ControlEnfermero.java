/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import proyecto.Modelo.Fecha;
import proyecto.Modelo.Paciente;
import proyecto.Modelo.Quimioterapia;
import proyecto.Modelo.SignosVitales;
import proyecto.Modelo.Suministro;
import proyecto.Modelo.Terminal;
import proyecto.login.Login;
import proyecto.registro.PacientesDAO;
import proyecto.registro.SuministrosDAO;
import proyecto.vista.EnfermeroPrincipal;
import proyecto.vista.EnfermeroSignosV;
import proyecto.vista.EnfermeroDarMedicamentos;



/**
 *
 * @author USER
 */
public class ControlEnfermero implements ActionListener, KeyListener {
    private EnfermeroPrincipal enfermeroPrincipal;
    private EnfermeroSignosV enfermeroSignosV;
    private EnfermeroDarMedicamentos darMedicamentos;
    
    
    public ControlEnfermero(EnfermeroPrincipal enfermeroPrincipal, EnfermeroSignosV enfermeroSignosV, EnfermeroDarMedicamentos darMedicamentos) {
        this.enfermeroPrincipal = enfermeroPrincipal;
        this.enfermeroSignosV = enfermeroSignosV;
        this.darMedicamentos= darMedicamentos;
        
        enfermeroPrincipal.getSignosVitalesButton().addActionListener(this);
        enfermeroPrincipal.getSuministrosButton().addActionListener(this);
        enfermeroPrincipal.getCerrarSesionButton().addActionListener(this);
        
        enfermeroSignosV.getNuevoButton().addActionListener(this);
        enfermeroSignosV.getActualizarButton().addActionListener(this);
        enfermeroSignosV.getAtrasButton().addActionListener(this);
        enfermeroSignosV.getPacienteComboBox().addActionListener(this);
        enfermeroSignosV.getFrecuenciaCardiacaTextField().addKeyListener(this);
        enfermeroSignosV.getPresionArterialTextField().addKeyListener(this);
        enfermeroSignosV.getTemperaturaTextField().addKeyListener(this);
        enfermeroSignosV.getPesoTextField().addKeyListener(this);
        enfermeroSignosV.getTallaTextField().addKeyListener(this);
        
        
        darMedicamentos.getAtrasButton().addActionListener(this);
        darMedicamentos.getGuardarButton().addActionListener(this);
        darMedicamentos.getPacienteComboBox().addActionListener(this);
        
    }
    
    private boolean enfermeroSignosVacio() {
        int pacienteIndex = enfermeroSignosV.getPacienteComboBox().getSelectedIndex();
        String frecuenciaCardiaca = enfermeroSignosV.getFrecuenciaCardiacaTextField().getText();
        String presionArterial = enfermeroSignosV.getPresionArterialTextField().getText();
        String temperatura = enfermeroSignosV.getTemperaturaTextField().getText();
        String talla = enfermeroSignosV.getTallaTextField().getText();
        String peso = enfermeroSignosV.getPesoTextField().getText();
        
        return (frecuenciaCardiaca.equals("") || presionArterial.equals("") || temperatura.equals("") || talla.equals("") || peso.equals("") || pacienteIndex == 0);
    }
    
    @Override
    public void actionPerformed(ActionEvent ae) {    
         if (ae.getSource().equals(enfermeroPrincipal.getSignosVitalesButton())) {
            //entrar Registro Signos Vitales
            enfermeroSignosV.getPacienteComboBox().removeAllItems();
            enfermeroSignosV.getPacienteComboBox().addItem("-Seleccione-");
            
            for (Paciente paciente : PacientesDAO.getPacientes())
                enfermeroSignosV.getPacienteComboBox().addItem(paciente.getCedula() + " - " + paciente.getNombre());
                
            enfermeroPrincipal.dispose();
            enfermeroSignosV.show();  
            enfermeroSignosV.getActualizarButton().setEnabled(false);
        }
        
        if (ae.getSource().equals(enfermeroPrincipal.getSuministrosButton())) {
            //entrar Registro Suministrar
            darMedicamentos.getPacienteComboBox().removeActionListener(this);
            darMedicamentos.getPacienteComboBox().removeAllItems();
            darMedicamentos.getPacienteComboBox().addItem("Todos");
            for (Paciente paciente : PacientesDAO.getPacientes())
                darMedicamentos.getPacienteComboBox().addItem(paciente.getCedula() + " - " + paciente.getNombre());
            darMedicamentos.getPacienteComboBox().addActionListener(this);

            enfermeroPrincipal.dispose();
            darMedicamentos.show();
            
            DefaultTableModel modelo = (DefaultTableModel) darMedicamentos.getjTable1().getModel();
            modelo.setRowCount(0);
            for (Suministro suministro : SuministrosDAO.getSuministros()) {
                if (!suministro.Cumplido() && Login.getUsuario().equals(suministro.getEnfermero().getCedula())) {
                    Object[] fila = new Object[] {suministro.getId(), suministro.getReceta().getPaciente().getNombre(), suministro.getMedicamento().getNombre() +  " (" + suministro.getMedicamento().getDosis() + ")", suministro.getFecha().horaString(), false};
                    modelo.addRow(fila);
                }
            }
            
        }
        
         if (ae.getSource().equals(enfermeroPrincipal.getCerrarSesionButton())) {
            //entrar Registro Suministrar
            enfermeroPrincipal.dispose();
            //suministroMedicamento.show();
            
        }
        
        if (ae.getSource().equals(enfermeroSignosV.getNuevoButton())) {
            //nuevo registro
            enfermeroSignosV.getFrecuenciaCardiacaTextField().setEnabled(true);
            enfermeroSignosV.getFrecuenciaCardiacaTextField().setText("");
            
            enfermeroSignosV.getTemperaturaTextField().setEnabled(true);
            enfermeroSignosV.getTemperaturaTextField().setText("");
            
            enfermeroSignosV.getPresionArterialTextField().setEnabled(true);
            enfermeroSignosV.getPresionArterialTextField().setText("");
            
            enfermeroSignosV.getTallaTextField().setEnabled(true);
            enfermeroSignosV.getTallaTextField().setText("");
            
            enfermeroSignosV.getPesoTextField().setEnabled(true);
            enfermeroSignosV.getPesoTextField().setText("");
            
            enfermeroSignosV.getPacienteComboBox().setSelectedItem("-Seleccione-");
            enfermeroSignosV.getPacienteComboBox().setEnabled(true);
        }
        
         if (ae.getSource().equals(enfermeroSignosV.getAtrasButton())) {
            enfermeroSignosV.dispose();
            enfermeroPrincipal.show();
        }
         if (ae.getSource().equals(enfermeroSignosV.getActualizarButton())) {
            enfermeroSignosV.getFrecuenciaCardiacaTextField().setEnabled(false);
            enfermeroSignosV.getTemperaturaTextField().setEnabled(false);         
            enfermeroSignosV.getPresionArterialTextField().setEnabled(false);     
            enfermeroSignosV.getTallaTextField().setEnabled(false);       
            enfermeroSignosV.getPesoTextField().setEnabled(false);         
            enfermeroSignosV.getPacienteComboBox().setEnabled(false);
            
            int frecuencia = Integer.parseInt(enfermeroSignosV.getFrecuenciaCardiacaTextField().getText());
            int presion = Integer.parseInt(enfermeroSignosV.getPresionArterialTextField().getText());
            int talla = Integer.parseInt(enfermeroSignosV.getTallaTextField().getText());
            int peso = Integer.parseInt(enfermeroSignosV.getPesoTextField().getText());
            float temperatura = Float.parseFloat(enfermeroSignosV.getTemperaturaTextField().getText());
            
            Paciente paciente = PacientesDAO.getPacientes().get(enfermeroSignosV.getPacienteComboBox().getSelectedIndex() -1);
            paciente.setSignosVitales(new SignosVitales(frecuencia, presion, talla, peso, temperatura, new Fecha()));
            
            boolean isTerminal = false;
            for (Terminal terminal : PacientesDAO.getTerminales()) {
                if (terminal.getCedula().equals(paciente.getCedula()))
                    isTerminal = true;
            }
            
            
            if (isTerminal) {
                Terminal terminal = (Terminal) paciente;
                PacientesDAO.actualizar(terminal);
                JOptionPane.showMessageDialog(enfermeroSignosV,"Actualizado con exito!");
            }
            else {
                Quimioterapia quimioterapia = (Quimioterapia) paciente;
                PacientesDAO.actualizar(quimioterapia);
                JOptionPane.showMessageDialog(enfermeroSignosV,"Actualizado con exito");
            }
        }
         
         // SUMINISTRAR
//        ----------------------------------------------------------------------------------------------
        if (ae.getSource().equals(darMedicamentos.getPacienteComboBox())) {
            DefaultTableModel modelo = (DefaultTableModel) darMedicamentos.getjTable1().getModel();
            modelo.setRowCount(0);
            
            if (darMedicamentos.getPacienteComboBox().getSelectedIndex() != 0) {
                Paciente paciente = PacientesDAO.getPacientes().get(darMedicamentos.getPacienteComboBox().getSelectedIndex() - 1);

                for (Suministro suministro : SuministrosDAO.getSuministros()) {
                    if (suministro.getReceta().getPaciente().getCedula().equals(paciente.getCedula()) && !suministro.Cumplido() && Login.getUsuario().equals(suministro.getEnfermero().getCedula())) {
                        Object[] fila = new Object[] {suministro.getId(), suministro.getReceta().getPaciente().getNombre(), suministro.getMedicamento().getNombre() +  " (" + suministro.getMedicamento().getDosis() + ")", suministro.getFecha().horaString(), false};
                        modelo.addRow(fila);
                        
                    }   
                }
            } else {
                for (Suministro suministro : SuministrosDAO.getSuministros()) {
                    if (!suministro.Cumplido() && Login.getUsuario().equals(suministro.getEnfermero().getCedula())) {
                        Object[] fila = new Object[] {suministro.getId(), suministro.getReceta().getPaciente().getNombre(), suministro.getMedicamento().getNombre() +  " (" + suministro.getMedicamento().getDosis() + ")", suministro.getFecha().horaString(), false};
                        modelo.addRow(fila);
                        
                    }
                }
            }
        }
        
        if (ae.getSource().equals(darMedicamentos.getAtrasButton())) {
            darMedicamentos.dispose();
            enfermeroPrincipal.show();
        }
        
        if (ae.getSource().equals(darMedicamentos.getGuardarButton())) {
          //ESCRIBIR CODIGO
            boolean confirmacion = false;
            
            for (int i = 0; i < darMedicamentos.getjTable1().getRowCount(); i++) {
                if ((boolean) darMedicamentos.getjTable1().getValueAt(i, 4)) {
                    int id = Integer.parseInt(darMedicamentos.getjTable1().getValueAt(i, 0).toString());
                    Suministro suministro = SuministrosDAO.find(id);
                    suministro.setCumplido(true);
                    SuministrosDAO.actulizar(suministro);

                    confirmacion = true;
                }      
            }
            JOptionPane.showMessageDialog(darMedicamentos,"Suministros confirmados con exito!");
            
            if (confirmacion)
                JOptionPane.showMessageDialog(darMedicamentos,"Suministros confirmados con exito!");
            
            DefaultTableModel modelo = (DefaultTableModel) darMedicamentos.getjTable1().getModel();
            modelo.setRowCount(0);
            
            if (darMedicamentos.getPacienteComboBox().getSelectedIndex() != 0) {
                Paciente paciente = PacientesDAO.getPacientes().get(darMedicamentos.getPacienteComboBox().getSelectedIndex() - 1);

                for (Suministro suministro : SuministrosDAO.getSuministros()) {
                    if (suministro.getReceta().getPaciente().getCedula().equals(paciente.getCedula()) && !suministro.Cumplido() && Login.getUsuario().equals(suministro.getEnfermero().getCedula())) {
                        Object[] fila = new Object[] {suministro.getId(), suministro.getReceta().getPaciente().getNombre(), suministro.getMedicamento().getNombre() +  " (" + suministro.getMedicamento().getDosis() + ")", suministro.getFecha().horaString(), false};
                        modelo.addRow(fila);
                    }
                    
                }
            } else {
                for (Suministro suministro : SuministrosDAO.getSuministros()) {
                    if (!suministro.Cumplido() && Login.getUsuario().equals(suministro.getEnfermero().getCedula())) {
                        Object[] fila = new Object[] {suministro.getId(), suministro.getReceta().getPaciente().getNombre(), suministro.getMedicamento().getNombre() +  " (" + suministro.getMedicamento().getDosis() + ")", suministro.getFecha().horaString(), false};
                        modelo.addRow(fila);
                    }
                    
                }
            }
            
        }
        
        if (ae.getSource().equals(enfermeroSignosV.getPacienteComboBox())) {
            enfermeroSignosV.getActualizarButton().setEnabled(!enfermeroSignosVacio());
        }
      
        
    }

    @Override
    public void keyTyped(KeyEvent ke) {
        char c = ke.getKeyChar();
        
        if (ke.getSource().equals(enfermeroSignosV.getFrecuenciaCardiacaTextField())) {
            if (!Character.isDigit(c) || enfermeroSignosV.getFrecuenciaCardiacaTextField().getText().length() >= 3)
                ke.consume(); // Limita a 3 caracteres numéricos
        }
        
        if (ke.getSource().equals(enfermeroSignosV.getPresionArterialTextField())) {
            if (!Character.isDigit(c) || enfermeroSignosV.getPresionArterialTextField().getText().length() >= 3)
             ke.consume(); // Limita a 3 caracteres numéricos
        }
        
        if (ke.getSource().equals(enfermeroSignosV.getTemperaturaTextField())) {
            if (!Character.isDigit(c) || enfermeroSignosV.getTemperaturaTextField().getText().length() >= 5)
                ke.consume(); // Limita a 12 caracteres numéricos y un punto decimal
            
            if (enfermeroSignosV.getTemperaturaTextField().getText().length() == 2)
                if (Character.isDigit(c))
                    enfermeroSignosV.getTemperaturaTextField().setText(enfermeroSignosV.getTemperaturaTextField().getText() + ".");
        }
        
        if (ke.getSource().equals(enfermeroSignosV.getTallaTextField())) {
            if (!Character.isDigit(c) || enfermeroSignosV.getTallaTextField().getText().length() >= 3)
                ke.consume(); // Limita a 3 caracteres numéricos
        }
        
        if (ke.getSource().equals(enfermeroSignosV.getPesoTextField())) {
            if (!Character.isDigit(c) || enfermeroSignosV.getPesoTextField().getText().length() >= 3)
                ke.consume(); // Limita a 3 caracteres numéricos
        }
        
    }

    @Override
    public void keyPressed(KeyEvent ke) {
    }

    @Override
    public void keyReleased(KeyEvent ke) {
        Object obj = ke.getSource();
        if (
            obj.equals(enfermeroSignosV.getFrecuenciaCardiacaTextField())
            || obj.equals(enfermeroSignosV.getPresionArterialTextField())
            || obj.equals(enfermeroSignosV.getTemperaturaTextField())
            || obj.equals(enfermeroSignosV.getPesoTextField())
            || obj.equals(enfermeroSignosV.getTallaTextField())
        ) {
            enfermeroSignosV.getActualizarButton().setEnabled(!enfermeroSignosVacio());         
        }
    }
    
}
