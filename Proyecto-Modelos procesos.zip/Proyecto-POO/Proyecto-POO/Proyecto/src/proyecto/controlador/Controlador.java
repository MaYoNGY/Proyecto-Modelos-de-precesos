/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import proyecto.login.Login;
import proyecto.vista.AdmiPrincipal;
import proyecto.vista.EnfermeroPrincipal;
import proyecto.vista.MedicoPrincipal;
import proyecto.vista.Principal;

/**
 *
 * @author Windows
 */
public class Controlador implements ActionListener, KeyListener {
    private Login login;
    private final Principal principal;
    private final AdmiPrincipal admiPrincipal;
    private final MedicoPrincipal medicoPrincipal;
    private final EnfermeroPrincipal enfermeroPrincipal;

    public Controlador(Login login, Principal principal, AdmiPrincipal admiPrincipal, MedicoPrincipal medicoPrincipal, EnfermeroPrincipal enfermeroPrincipal) {
        this.login = login;
        this.principal = principal;
        this.admiPrincipal = admiPrincipal;
        this.medicoPrincipal = medicoPrincipal;
        this.enfermeroPrincipal = enfermeroPrincipal;
        
        principal.getUsuarioTextField().addKeyListener(this);
        principal.getContraseñaField().addKeyListener(this);
        principal.getIngresarButton().addActionListener(this);
        admiPrincipal.getCerrarSesionButton().addActionListener(this);
        medicoPrincipal.getCerrarSesionButton().addActionListener(this);
        enfermeroPrincipal.getCerrarSesionButton().addActionListener(this);
        
    }
    
    @Override
    public void actionPerformed(ActionEvent ae) {

        if (ae.getSource().equals(principal.getIngresarButton())) {
            String usuario = principal.getUsuarioTextField().getText(), contrasena = new String(principal.getContraseñaField().getPassword());
            
            login = new Login(usuario, contrasena, principal, admiPrincipal, medicoPrincipal, enfermeroPrincipal);
            login.getContext().iniciarSesion();
        }    
        if(ae.getSource().equals(admiPrincipal.getCerrarSesionButton())) {
            admiPrincipal.setVisible(false);
            principal.getUsuarioTextField().setText("");
            principal.getContraseñaField().setText("");
            principal.getIngresarButton().setEnabled(false);
            principal.setVisible(true);
            
            System.out.println("Log out: " + login.getContext().getUser().getNombre());
        }
        if(ae.getSource().equals(medicoPrincipal.getCerrarSesionButton())) {
            medicoPrincipal.setVisible(false);
            principal.getUsuarioTextField().setText("");
            principal.getContraseñaField().setText("");
            principal.getIngresarButton().setEnabled(false);
            principal.setVisible(true);
            
            System.out.println("Log out: " + login.getContext().getUser().getNombre());
        }
        if(ae.getSource().equals(enfermeroPrincipal.getCerrarSesionButton())) {
            enfermeroPrincipal.setVisible(false);
            principal.getUsuarioTextField().setText("");
            principal.getContraseñaField().setText("");
            principal.getIngresarButton().setEnabled(false);
            principal.setVisible(true);
            
            System.out.println("Log out: " + login.getContext().getUser().getNombre());
        }
    }

    @Override
    public void keyTyped(KeyEvent ke) {

    }

    @Override
    public void keyPressed(KeyEvent ke) {
    }

    @Override
    public void keyReleased(KeyEvent ke) {
        String usuario = principal.getUsuarioTextField().getText();
        String contrasena = new String(principal.getContraseñaField().getPassword());

//        if (
//            ke.getSource().equals(principal.getUsuarioTextField()) 
//            || ke.getSource().equals(principal.getContraseñaField())
//        ) {
            boolean vacio = (
                usuario.equals("") 
                || contrasena.equals("")
            );
            
            principal.getIngresarButton().setEnabled(!vacio);
//        }
    }
}
