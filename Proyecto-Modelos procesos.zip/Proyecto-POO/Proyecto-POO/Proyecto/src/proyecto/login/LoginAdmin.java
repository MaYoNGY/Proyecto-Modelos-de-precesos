/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.login;

import proyecto.Modelo.Educacion;
import proyecto.Modelo.Empleado;
import proyecto.vista.AdmiPrincipal;
import proyecto.vista.Principal;

/**
 *
 * @author Windows
 */
public class LoginAdmin implements LoginStrategy {
    private final Principal principal;
    private final AdmiPrincipal admiPrincipal;

    public LoginAdmin(Principal principal, AdmiPrincipal admiPrincipal) {
        this.principal = principal;
        this.admiPrincipal = admiPrincipal;
    }

    @Override
    public void iniciarSesion() {
        System.out.println("Log in: Admin");
        principal.setVisible(false);
        admiPrincipal.setVisible(true);
    }

    @Override
    public Empleado getUser() {
        return new Empleado("9999999999", "Admin", new Educacion("", ""));
    }
    
}
