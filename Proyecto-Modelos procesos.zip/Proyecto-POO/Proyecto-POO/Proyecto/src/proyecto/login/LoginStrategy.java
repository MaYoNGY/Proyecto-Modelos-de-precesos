/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.login;

import proyecto.Modelo.Empleado;

/**
 *
 * @author Windows
 */
public interface LoginStrategy {
    public void iniciarSesion();
    public Empleado getUser();
}
