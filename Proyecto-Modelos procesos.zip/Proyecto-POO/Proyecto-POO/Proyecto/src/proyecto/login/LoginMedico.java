/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.login;

import proyecto.Modelo.Empleado;
import proyecto.Modelo.Medico;
import proyecto.vista.MedicoPrincipal;
import proyecto.vista.Principal;

/**
 *
 * @author Windows
 */
public class LoginMedico implements LoginStrategy {
    private final Medico medico;
    private final Principal principal;
    private final MedicoPrincipal medicoPrincipal;

    public LoginMedico(Medico medico, Principal principal, MedicoPrincipal medicoPrincipal) {
        this.medico = medico;
        this.principal = principal;
        this.medicoPrincipal = medicoPrincipal;
    }

    @Override
    public void iniciarSesion() {
        System.out.println("Log in: " + medico.getCedula() + " - " + medico.getNombre());
        principal.setVisible(false);
        medicoPrincipal.setVisible(true);
        medicoPrincipal.getBienvenidaLabel().setText(medico.getNombre().toUpperCase());
    }

    @Override
    public Empleado getUser() {
        return medico;
    }
    
}
