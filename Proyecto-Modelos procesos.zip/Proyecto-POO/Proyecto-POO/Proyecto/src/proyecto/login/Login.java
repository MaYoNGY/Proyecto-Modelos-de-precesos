/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.login;

import proyecto.Modelo.Enfermero;
import proyecto.Modelo.Medico;
import proyecto.registro.EmpleadosDAO;
import proyecto.vista.AdmiPrincipal;
import proyecto.vista.EnfermeroPrincipal;
import proyecto.vista.MedicoPrincipal;
import proyecto.vista.Principal;

/**
 *
 * @author Windows
 */
public class Login {
    private LoginStrategy contexto;
    private static String usuario, contrasena;
    private Medico medico;
    private Enfermero enfermero;
    private final Principal principal;
    private final AdmiPrincipal admiPrincipal;
    private final MedicoPrincipal medicoPrincipal;
    private final EnfermeroPrincipal enfermeroPrincipal;

    public Login(String usuario, String contrasena, Principal principal, AdmiPrincipal admiPrincipal, MedicoPrincipal medicoPrincipal, EnfermeroPrincipal enfermeroPrincipal) {
        this.usuario = usuario;
        this.contrasena = contrasena;
        this.principal = principal;
        this.admiPrincipal = admiPrincipal;
        this.medicoPrincipal = medicoPrincipal;
        this.enfermeroPrincipal = enfermeroPrincipal;
    }
    
    public LoginStrategy getContext() {
        if (usuario.equals("admin") && contrasena.equals("password")) {
            return new LoginAdmin(principal, admiPrincipal);
        }
        
        for (Medico medico : EmpleadosDAO.getMedicos())
            if (usuario.equals(medico.getCedula()) && contrasena.equals(medico.getCedula()))
                return new LoginMedico(medico, principal, medicoPrincipal);
        
        for (Enfermero enfermero : EmpleadosDAO.getEnfermeros())
            if (usuario.equals(enfermero.getCedula()) && contrasena.equals(enfermero.getCedula()))
                return new LoginEnfermero(enfermero, principal, enfermeroPrincipal);
        
        return new LoginNoValido(principal);
    }
    
    public static String getUsuario() {
        return usuario;
    } 
}
