/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.login;

import javax.swing.JOptionPane;
import proyecto.Modelo.Empleado;
import proyecto.vista.Principal;

/**
 *
 * @author Windows
 */
public class LoginNoValido implements LoginStrategy {
    Principal principal;

    public LoginNoValido(Principal principal) {
        this.principal = principal;
    }

    @Override
    public void iniciarSesion() {
        System.out.println("Log in fallido.");
        JOptionPane.showMessageDialog(principal, "Usuario y/o contraseña no válido.");
        principal.getUsuarioTextField().setText("");
        principal.getContraseñaField().setText("");
        principal.getIngresarButton().setEnabled(false);
    }

    @Override
    public Empleado getUser() {
        return null;
    }
    
}
