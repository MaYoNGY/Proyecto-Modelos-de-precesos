/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.login;

import proyecto.Modelo.Empleado;
import proyecto.Modelo.Enfermero;
import proyecto.vista.EnfermeroPrincipal;
import proyecto.vista.Principal;

/**
 *
 * @author Windows
 */
public class LoginEnfermero implements LoginStrategy {
    private final Enfermero enfermero;
    private final Principal principal;
    private final EnfermeroPrincipal enfermeroPrincipal;

    public LoginEnfermero(Enfermero enfermero, Principal principal, EnfermeroPrincipal enfermeroPrincipal) {
        this.enfermero = enfermero;
        this.principal = principal;
        this.enfermeroPrincipal = enfermeroPrincipal;
    }

    @Override
    public void iniciarSesion() {
        System.out.println("Log in: " + enfermero.getCedula() + " - " + enfermero.getNombre());
        principal.setVisible(false);
        enfermeroPrincipal.setVisible(true);
        enfermeroPrincipal.getBienvenidaLabel().setText(enfermero.getNombre().toUpperCase());
    }

    @Override
    public Empleado getUser() {
        return enfermero;
    }
    
}
