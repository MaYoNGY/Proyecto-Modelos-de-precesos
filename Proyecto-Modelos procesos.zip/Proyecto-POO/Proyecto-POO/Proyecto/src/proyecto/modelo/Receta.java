/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.Modelo;

import java.util.ArrayList;

/**
 *
 * @author Windows
 */
public class Receta {
    private final int id;
    private final Fecha fecha;
    private final Medico medico;
    private final Paciente paciente;
    private final ArrayList<Medicamento> medicamentos;
    private final String diagnostico, indicaciones;

    public Receta(int id, Medico medico, Paciente paciente, ArrayList<Medicamento> medicamentos, String diagnostico, String indicaciones) {
        this.id = id;
        fecha = new Fecha();
        this.medico = medico;
        this.paciente = paciente;
        this.medicamentos = medicamentos;
        this.diagnostico = diagnostico;
        this.indicaciones = indicaciones;
    }
    
    public int getId() {
        return id;
    }

    public Fecha getFecha() {
        return fecha;
    }

    public Medico getMedico() {
        return medico;
    }

    public Paciente getPaciente() {
        return paciente;
    }

    public ArrayList<Medicamento> getMedicamentos() {
        return medicamentos;
    }

    public String getDiagnostico() {
        return diagnostico;
    }

    public String getIndicaciones() {
        return indicaciones;
    }

    @Override
    public String toString() {
        return "Receta{" + "id=" + id + ", fecha=" + fecha + ", medico=" + medico + ", paciente=" + paciente + ", medicamentos=" + medicamentos + ", diagnostico=" + diagnostico + ", indicaciones=" + indicaciones + '}';
    }
    
}
