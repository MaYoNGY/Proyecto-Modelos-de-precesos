/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.Modelo;

/**
 *
 * @author Windows
 */
public class SignosVitales {
    private int frecuenciaCardiaca, presionArterial, talla, peso; 
    private float temperatura;
    private final Fecha fecha;

    public SignosVitales() {
        frecuenciaCardiaca = 0;
        presionArterial = 0;
        talla = 0;
        peso = 0;
        temperatura = 0;
        fecha = new Fecha();
    }

    public SignosVitales(int frecuenciaCardiaca, int presionArterial, int talla, int peso, float temperatura, Fecha fecha) {
        this.frecuenciaCardiaca = frecuenciaCardiaca;
        this.presionArterial = presionArterial;
        this.talla = talla;
        this.peso = peso;
        this.temperatura = temperatura;
        this.fecha = fecha;
    }

    public int getFrecuenciaCardiaca() {
        return frecuenciaCardiaca;
    }

    public void setFrecuenciaCardiaca(int frecuenciaCardiaca) {
        this.frecuenciaCardiaca = frecuenciaCardiaca;
    }

    public int getPresionArterial() {
        return presionArterial;
    }

    public void setPresionArterial(int presionArterial) {
        this.presionArterial = presionArterial;
    }

    public int getTalla() {
        return talla;
    }

    public void setTalla(int talla) {
        this.talla = talla;
    }

    public int getPeso() {
        return peso;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }

    public float getTemperatura() {
        return temperatura;
    }

    public void setTemperatura(float temperatura) {
        this.temperatura = temperatura;
    }

    public Fecha getFecha() {
        return fecha;
    }

    @Override
    public String toString() {
        return "SignosVitales{" + "frecuenciaCardiaca=" + frecuenciaCardiaca + ", presionArterial=" + presionArterial + ", talla=" + talla + ", peso=" + peso + ", temperatura=" + temperatura + ", fecha=" + fecha + '}';
    }
    
}
