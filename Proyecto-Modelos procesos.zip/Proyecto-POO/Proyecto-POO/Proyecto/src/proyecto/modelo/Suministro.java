/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.Modelo;

/*
Idea: Darle mejor funcionalidad a suministro haciendo que se creen de manera automática con la receta

*/

/**
 *
 * @author Windows
 */
public class Suministro {
    private final int id;
    private final Fecha fecha;
    private final Receta receta;
    private final Enfermero enfermero;
    private final Medicamento medicamento;
    private boolean cumplido;

    public Suministro(int id, Fecha fecha, Receta receta, Enfermero enfermero, Medicamento medicamento, boolean cumplido) {
        this.id = id;
        this.fecha = fecha;
        this.receta = receta;
        this.enfermero = enfermero;
        this.medicamento = medicamento;
        this.cumplido = cumplido;
    }
    
    public Suministro(int id, Fecha fecha, Receta receta, Enfermero enfermero, Medicamento medicamento) {
        this.id = id;
        this.fecha = fecha;
        this.receta = receta;
        this.enfermero = enfermero;
        this.medicamento = medicamento;
        this.cumplido = false;
    }

    public int getId() {
        return id;
    }
    
    public Fecha getFecha() {
        return fecha;
    }

    public Receta getReceta() {
        return receta;
    }

    public Enfermero getEnfermero() {
        return enfermero;
    }

    public Medicamento getMedicamento() {
        return medicamento;
    }

    public boolean Cumplido() {
        return cumplido;
    }

    public void setCumplido(boolean cumplido) {
        this.cumplido = cumplido;
    }
    
}
