/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.Modelo;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Windows
 */
public class Fecha extends Date {
        
    public Fecha() {
        super();       
    }
    
    public Fecha(long time) {
        super(time);
    }
    
    public String fechaString() {
        SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy/MM/dd");
        return formatoFecha.format(this);
    }
    
    public String horaString() {
        SimpleDateFormat formatoFecha = new SimpleDateFormat("HH:mm");
        return formatoFecha.format(this);
    }
    
    public String tiempoString() {
        return fechaString() + " - " + horaString();
    }

    public void consola() {
        System.out.println(tiempoString());
    }

    @Override
    public String toString() {
        return "Fecha{" + '}';
    }
    
}
