/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.Modelo;

/**
 *
 * @author Windows
 */
public class Quimioterapia extends Paciente {
    
    public Quimioterapia(String cedula, String nombre) {
        super(cedula, nombre);
    }

    public Quimioterapia(String cedula, String nombre, SignosVitales signosVitales) {
        super(cedula, nombre, signosVitales);
    }
    
}
