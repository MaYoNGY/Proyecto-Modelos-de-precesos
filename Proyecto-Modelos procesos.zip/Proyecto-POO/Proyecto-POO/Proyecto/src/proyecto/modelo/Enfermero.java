/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.Modelo;

/**
 *
 * @author Windows
 */
public class Enfermero extends Empleado {
    
    public Enfermero(String cedula, String nombre, Educacion educacion) {
        super(cedula, nombre, educacion);
    }
    
}
