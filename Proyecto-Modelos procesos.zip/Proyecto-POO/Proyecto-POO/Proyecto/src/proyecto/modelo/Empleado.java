/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.Modelo;

/**
 *
 * @author Windows
 */
public class Empleado {
    protected final String cedula, nombre;
    protected final Educacion educacion;

    public Empleado(String cedula, String nombre, Educacion educacion) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.educacion = educacion;
    }

    public String getCedula() {
        return cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public Educacion getEducacion() {
        return educacion;
    }

    @Override
    public String toString() {
        return "Empleado{" + "cedula=" + cedula + ", nombre=" + nombre + ", educacion=" + educacion + '}';
    }
    
    public void consola() {
        System.out.println(toString());
    }
}
