/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.Modelo;

/**
 *
 * @author Windows
 */
public class Medicamento {
    private final String nombre, presentacion, dosis;

    public Medicamento(String nombre, String presentacion, String dosis) {
        this.nombre = nombre;
        this.presentacion = presentacion;
        this.dosis = dosis;

    }

    public String getNombre() {
        return nombre;
    }

    public String getPresentacion() {
        return presentacion;
    }

    public String getDosis() {
        return dosis;
    }

    @Override
    public String toString() {
        return "Medicamento{" + "nombre=" + nombre + ", presentacion=" + presentacion + ", dosis=" + dosis + '}';
    }
    
    

    
}
