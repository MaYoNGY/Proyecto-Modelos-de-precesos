/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.Modelo;

/**
 *
 * @author Windows
 */
public class Paciente {
    protected final String cedula, nombre;
    protected SignosVitales signosVitales;

    public Paciente(String cedula, String nombre) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.signosVitales = new SignosVitales();
    }

    public Paciente(String cedula, String nombre, SignosVitales signosVitales) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.signosVitales = signosVitales;
    }

    public String getCedula() {
        return cedula;
    }

    public String getNombre() {
        return nombre;
    }

    public SignosVitales getSignosVitales() {
        return signosVitales;
    }

    public void setSignosVitales(SignosVitales signosVitales) {
        this.signosVitales = signosVitales;
    }

    @Override
    public String toString() {
        return "Paciente{" + "cedula=" + cedula + ", nombre=" + nombre + ", signosVitales=" + signosVitales + '}';
    } 
}
