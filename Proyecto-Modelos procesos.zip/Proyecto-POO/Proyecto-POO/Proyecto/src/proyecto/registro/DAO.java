/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.registro;

import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;

/**
 *
 * @author Windows
 */
public class DAO {
    private static MongoClient conexion;
    protected static DB database;
    protected static DBCollection coleccion;
    
    public static void conectar() {
        conexion = new MongoClient("localhost", 27017); 
        database = conexion.getDB("Proyecto");
    }
    
}
