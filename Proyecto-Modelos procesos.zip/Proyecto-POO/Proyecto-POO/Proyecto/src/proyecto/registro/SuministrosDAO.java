/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.registro;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import java.util.ArrayList;
import proyecto.Modelo.Enfermero;
import proyecto.Modelo.Fecha;
import proyecto.Modelo.Medicamento;
import proyecto.Modelo.Receta;
import proyecto.Modelo.Suministro;
import static proyecto.registro.DAO.coleccion;

/**
 *
 * @author USER
 */
public class SuministrosDAO extends DAO {
    
    public static ArrayList<Suministro> getSuministros() {
        coleccion = database.getCollection("Suministros");
        
        ArrayList<Suministro> suministros = new ArrayList();
        
        DBCursor cursor = coleccion.find();
        while (cursor.hasNext()) {
            DBObject suministroObj = cursor.next(); 

            int id = Integer.parseInt(suministroObj.get("id").toString());
            Fecha fecha = new Fecha(Long.parseLong(suministroObj.get("fecha").toString()));
            Receta receta = RecetasDAO.findReceta(Integer.parseInt(suministroObj.get("receta_id").toString()));
            Enfermero enfermero = EmpleadosDAO.findEnfermero(suministroObj.get("enfermero_cedula").toString());
            
            DBObject medicamento = (DBObject) suministroObj.get("medicamento");
            String medicamento_nombre = medicamento.get("nombre").toString();
            String medicamento_presentacion = medicamento.get("presentacion").toString();
            String medicamento_dosis = medicamento.get("dosis").toString();
            
            boolean cumplido = Boolean.parseBoolean(suministroObj.get("cumplido").toString());
            
            suministros.add(new Suministro(id, fecha, receta, enfermero, new Medicamento(medicamento_nombre, medicamento_presentacion, medicamento_dosis), cumplido));
        }
        
        return suministros;
    }
    
    public static boolean isRepeated(Suministro suministro) {
        for (Suministro s : getSuministros())
            if (s.getId() == suministro.getId())
                return true;
        
        return false;
    }
    
    public static void add(Suministro suministro) {
        if (!isRepeated(suministro)) {
            BasicDBObject documento = new BasicDBObject();
            documento.put("id", suministro.getId());
            documento.put("fecha", suministro.getFecha().getTime());
            documento.put("receta_id", suministro.getReceta().getId());
            documento.put("enfermero_cedula", suministro.getEnfermero().getCedula());
            
            BasicDBObject documento_medicamento = new BasicDBObject();
            documento_medicamento.put("nombre", suministro.getMedicamento().getNombre());
            documento_medicamento.put("presentacion", suministro.getMedicamento().getPresentacion());
            documento_medicamento.put("dosis", suministro.getMedicamento().getDosis());
            documento.append("medicamento", documento_medicamento);
            
            documento.put("cumplido", suministro.Cumplido());

            coleccion = database.getCollection("Suministros");
            coleccion.insert(documento);
        }
    }
    
    public static void actulizar(Suministro suministro) {
            BasicDBObject documento = new BasicDBObject();
            documento.put("id", suministro.getId());
            documento.put("fecha", suministro.getFecha().getTime());
            documento.put("receta_id", suministro.getReceta().getId());
            documento.put("enfermero_cedula", suministro.getEnfermero().getCedula());
            
            BasicDBObject documento_medicamento = new BasicDBObject();
            documento_medicamento.put("nombre", suministro.getMedicamento().getNombre());
            documento_medicamento.put("presentacion", suministro.getMedicamento().getPresentacion());
            documento_medicamento.put("dosis", suministro.getMedicamento().getDosis());
            documento.append("medicamento", documento_medicamento);
            
            documento.put("cumplido", suministro.Cumplido());

            BasicDBObject filtro = new BasicDBObject();
            filtro.append("id", suministro.getId());

            BasicDBObject query = new BasicDBObject();
            query.append("$set", documento);

            coleccion = database.getCollection("Suministros");
            coleccion.updateMulti(filtro, query);
    }
    
    public static int id() {
        if (getSuministros().isEmpty())
            return 1;
        
        Suministro suministro = getSuministros().get(getSuministros().size() - 1);
        return suministro.getId() + 1;
    }
    
    
    public static Suministro find(int id) {
        for (Suministro suministro : SuministrosDAO.getSuministros())
            if (suministro.getId() == id)
                return suministro;
        
        return null;
    }
}
