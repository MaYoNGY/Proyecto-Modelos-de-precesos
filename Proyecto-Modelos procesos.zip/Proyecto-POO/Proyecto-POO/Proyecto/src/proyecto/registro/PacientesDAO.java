/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.registro;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import java.util.LinkedList;
import proyecto.Modelo.Fecha;
import proyecto.Modelo.Paciente;
import proyecto.Modelo.Quimioterapia;
import proyecto.Modelo.SignosVitales;
import proyecto.Modelo.Terminal;
import static proyecto.registro.DAO.coleccion;

/**
 *
 * @author Windows
 */
public class PacientesDAO extends DAO {
    
    public static LinkedList<Terminal> getTerminales() {
        coleccion = database.getCollection("Terminales");
        
        LinkedList<Terminal> terminales = new LinkedList();
        DBCursor cursor = coleccion.find();
        
        while (cursor.hasNext()) {
            DBObject terminalObj = cursor.next();
            String cedula = terminalObj.get("cedula").toString();
            String nombre = terminalObj.get("nombre").toString();
            
            DBObject svObject = (DBObject) terminalObj.get("signos_vitales");
            int frecuencia = Integer.parseInt(svObject.get("frecuencia").toString());
            int presion = Integer.parseInt(svObject.get("presion").toString());
            int talla = Integer.parseInt(svObject.get("talla").toString());
            int peso = Integer.parseInt(svObject.get("peso").toString());
            float temperatura = Float.parseFloat(svObject.get("temperatura").toString());
            Fecha fecha = new Fecha(Long.parseLong(svObject.get("fecha").toString()));
            
            terminales.add(new Terminal(cedula, nombre, new SignosVitales(frecuencia, presion, talla, peso, temperatura, fecha)));
        }
        
        return terminales;
    }
    
    public static LinkedList<Quimioterapia> getQuimioterapias() {
        coleccion = database.getCollection("Quimioterapias");
        
        LinkedList<Quimioterapia> quimioterapias = new LinkedList();
        DBCursor cursor = coleccion.find();
        
        while (cursor.hasNext()) {
            DBObject quimioterapiaObj = cursor.next();
            String cedula = quimioterapiaObj.get("cedula").toString();
            String nombre = quimioterapiaObj.get("nombre").toString();
            
            DBObject svObject = (DBObject) quimioterapiaObj.get("signos_vitales");
            int frecuencia = Integer.parseInt(svObject.get("frecuencia").toString());
            int presion = Integer.parseInt(svObject.get("presion").toString());
            int talla = Integer.parseInt(svObject.get("talla").toString());
            int peso = Integer.parseInt(svObject.get("peso").toString());
            float temperatura = Float.parseFloat(svObject.get("temperatura").toString());
            Fecha fecha = new Fecha(Long.parseLong(svObject.get("fecha").toString()));
            
            quimioterapias.add(new Quimioterapia(cedula, nombre, new SignosVitales(frecuencia, presion, talla, peso, temperatura, fecha)));
        }
        
        return quimioterapias;
    }
    
    public static LinkedList<Paciente> getPacientes() {
        LinkedList<Paciente> pacientes = new LinkedList();
        
        for (Terminal terminales : getTerminales())
            pacientes.add(terminales);
        
        for (Quimioterapia quimioterapia : getQuimioterapias())
            pacientes.add(quimioterapia);
        
        return pacientes;
    }
    
    public static boolean isRepetido(Paciente paciente) {
        for (Paciente p : getPacientes())
            if (p.getCedula().equals(paciente.getCedula()))
                return true;
        
        return false;
    }
    
    public static void add(Terminal terminal) {
        if (!isRepetido(terminal)) {
            BasicDBObject documento = new BasicDBObject();
            documento.put("cedula", terminal.getCedula());
            documento.put("nombre", terminal.getNombre());
            
            BasicDBObject svDocumento = new BasicDBObject();
            svDocumento.put("frecuencia", terminal.getSignosVitales().getFrecuenciaCardiaca());
            svDocumento.put("presion", terminal.getSignosVitales().getPresionArterial());
            svDocumento.put("talla", terminal.getSignosVitales().getTalla());
            svDocumento.put("peso", terminal.getSignosVitales().getPeso());
            svDocumento.put("temperatura", terminal.getSignosVitales().getTemperatura());
            svDocumento.put("fecha", terminal.getSignosVitales().getFecha().getTime());
            documento.append("signos_vitales", svDocumento);
            
            coleccion = database.getCollection("Terminales");
            coleccion.insert(documento);
        }
    }
    
    public static void actualizar(Terminal terminal) {
        BasicDBObject documento = new BasicDBObject();
        documento.put("cedula", terminal.getCedula());
        documento.put("nombre", terminal.getNombre());
        
        BasicDBObject svDocumento = new BasicDBObject();
        svDocumento.put("frecuencia", terminal.getSignosVitales().getFrecuenciaCardiaca());
        svDocumento.put("presion", terminal.getSignosVitales().getPresionArterial());
        svDocumento.put("talla", terminal.getSignosVitales().getTalla());
        svDocumento.put("peso", terminal.getSignosVitales().getPeso());
        svDocumento.put("temperatura", terminal.getSignosVitales().getTemperatura());
        svDocumento.put("fecha", terminal.getSignosVitales().getFecha().getTime());
        documento.append("signos_vitales", svDocumento);

        BasicDBObject filtro = new BasicDBObject();
        filtro.append("cedula", terminal.getCedula());
        
        BasicDBObject query = new BasicDBObject();
        query.append("$set", documento);
        
        coleccion = database.getCollection("Terminales");
        coleccion.updateMulti(filtro, query);
    }
    
    public static void add(Quimioterapia quimioterapia) {
        if (!isRepetido(quimioterapia)) {
            BasicDBObject documento = new BasicDBObject();
            documento.put("cedula", quimioterapia.getCedula());
            documento.put("nombre", quimioterapia.getNombre());
            
            BasicDBObject svDocumento = new BasicDBObject();
            svDocumento.put("frecuencia", quimioterapia.getSignosVitales().getFrecuenciaCardiaca());
            svDocumento.put("presion", quimioterapia.getSignosVitales().getPresionArterial());
            svDocumento.put("talla", quimioterapia.getSignosVitales().getTalla());
            svDocumento.put("peso", quimioterapia.getSignosVitales().getPeso());
            svDocumento.put("temperatura", quimioterapia.getSignosVitales().getTemperatura());
            svDocumento.put("fecha", quimioterapia.getSignosVitales().getFecha().getTime());
            documento.append("signos_vitales", svDocumento);
            
            coleccion = database.getCollection("Quimioterapias");
            coleccion.insert(documento);
        }
    }
    
    public static void actualizar(Quimioterapia quimioterapia) {
            BasicDBObject documento = new BasicDBObject();
            documento.put("cedula", quimioterapia.getCedula());
            documento.put("nombre", quimioterapia.getNombre());
            
            BasicDBObject svDocumento = new BasicDBObject();
            svDocumento.put("frecuencia", quimioterapia.getSignosVitales().getFrecuenciaCardiaca());
            svDocumento.put("presion", quimioterapia.getSignosVitales().getPresionArterial());
            svDocumento.put("talla", quimioterapia.getSignosVitales().getTalla());
            svDocumento.put("peso", quimioterapia.getSignosVitales().getPeso());
            svDocumento.put("temperatura", quimioterapia.getSignosVitales().getTemperatura());
            svDocumento.put("fecha", quimioterapia.getSignosVitales().getFecha().getTime());
            documento.append("signos_vitales", svDocumento);
            
            BasicDBObject filtro = new BasicDBObject();
            filtro.append("cedula", quimioterapia.getCedula());

            BasicDBObject query = new BasicDBObject();
            query.append("$set", documento);

            coleccion = database.getCollection("Quimioterapias");
            coleccion.updateMulti(filtro, query);
    }
    
    public static void remove(String cedula) {
        coleccion = database.getCollection("Terminales");
        coleccion.remove(new BasicDBObject().append("cedula", cedula));
        coleccion = database.getCollection("Quimioterapias");
        coleccion.remove(new BasicDBObject().append("cedula", cedula));
    }
    
    public static Terminal findTerminal(String cedula) {
        for (Terminal terminal : getTerminales())
            if (terminal.getCedula().equals(cedula))
                return terminal;
        
        return null;
    }
    
    public static Quimioterapia findQuimioterapia(String cedula) {
        for (Quimioterapia quimioterapia : getQuimioterapias())
            if (quimioterapia.getCedula().equals(cedula))
                return quimioterapia;
        
        return null;
    }
    
    public static Paciente findPaciente(String cedula) {
        for (Paciente paciente : getPacientes())
            if (paciente.getCedula().equals(cedula))
                return paciente;
        
        return null;
    }

}
