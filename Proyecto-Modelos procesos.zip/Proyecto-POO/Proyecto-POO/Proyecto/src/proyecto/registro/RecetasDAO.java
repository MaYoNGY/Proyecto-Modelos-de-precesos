/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.registro;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import java.util.ArrayList;
import java.util.LinkedList;
import proyecto.Modelo.Fecha;
import proyecto.Modelo.Medico;
import proyecto.Modelo.Paciente;
import proyecto.Modelo.Receta;

/**
 *
 * @author Windows
 */
public class RecetasDAO extends DAO {
    public static LinkedList<Receta> getRecetas() {
        coleccion = database.getCollection("Recetas");
        
        LinkedList<Receta> recetas = new LinkedList();
        DBCursor cursor = coleccion.find();
        
        while (cursor.hasNext()) {
            DBObject recetaObj = cursor.next();
            
            int id = Integer.parseInt(recetaObj.get("id").toString());
            Fecha fecha = new Fecha(Long.parseLong(recetaObj.get("fecha").toString()));
            Medico medico = EmpleadosDAO.findMedico(recetaObj.get("medico_cedula").toString());
            Paciente paciente = PacientesDAO.findTerminal(recetaObj.get("paciente_cedula").toString());
            String diagnostico = recetaObj.get("diagnostico").toString();
            String indicaciones = recetaObj.get("indicaciones").toString();
            
            recetas.add(new Receta(id, medico, paciente, new ArrayList(), diagnostico, indicaciones));
        }
        
        return recetas;
    }

    public static void add(Receta receta) {
        if (true) {
            BasicDBObject documento = new BasicDBObject();
            documento.put("id", receta.getId());
            documento.put("fecha", receta.getFecha().getTime());
            documento.put("medico_cedula", receta.getMedico().getCedula());
            documento.put("paciente_cedula", receta.getPaciente().getCedula());
            
            documento.put("diagnostico", receta.getDiagnostico());
            documento.put("indicaciones", receta.getIndicaciones());
            
            coleccion = database.getCollection("Recetas");
            coleccion.insert(documento);
        }
    }
    
    public static Receta findReceta(int id) {
        for (Receta receta : getRecetas())
            if (receta.getId() == id)
                return receta;
        
        return null;
    }
}
