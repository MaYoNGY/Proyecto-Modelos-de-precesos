/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.registro;

import com.mongodb.BasicDBObject;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import java.util.LinkedList;
import proyecto.Modelo.Educacion;
import proyecto.Modelo.Empleado;
import proyecto.Modelo.Enfermero;
import proyecto.Modelo.Medico;

/**
 *
 * @author Windows
 */
public class EmpleadosDAO extends DAO {
    
    public static LinkedList<Medico> getMedicos() {
        coleccion = database.getCollection("Medicos");
        
        LinkedList<Medico> medicos = new LinkedList();
        DBCursor cursor = coleccion.find();
        
        while (cursor.hasNext()) {
            DBObject medicoObj = cursor.next();
            String cedula = medicoObj.get("cedula").toString();
            String nombre = medicoObj.get("nombre").toString();
            
            DBObject educacion = (DBObject) medicoObj.get("educacion");
            String educacion_tipo = educacion.get("tipo").toString();
            String education_numero = educacion.get("numero_registro").toString();
            
            medicos.add(new Medico(cedula, nombre, new Educacion(educacion_tipo, education_numero)));
        }
        
        return medicos;
    }
    
    public static LinkedList<Enfermero> getEnfermeros() {
        coleccion = database.getCollection("Enfermeros");
        
        LinkedList<Enfermero> enfermeros = new LinkedList();
        DBCursor cursor = coleccion.find();
        
        while (cursor.hasNext()) {
            DBObject enfermeroObj = cursor.next();
            String cedula = enfermeroObj.get("cedula").toString();
            String nombre = enfermeroObj.get("nombre").toString();
            
            DBObject educacion = (DBObject) enfermeroObj.get("educacion");
            String educacion_tipo = educacion.get("tipo").toString();
            String education_numero = educacion.get("numero_registro").toString();
            
            enfermeros.add(new Enfermero(cedula, nombre, new Educacion(educacion_tipo, education_numero)));
        }
        
        return enfermeros;
    }
    
    public static LinkedList<Empleado> getEmpleados() {
        LinkedList<Empleado> empleados = new LinkedList();
        
        for (Medico medico : getMedicos())
            empleados.add(medico);
        
        for (Enfermero enfermero : getEnfermeros())
            empleados.add(enfermero);
        
        return empleados;
    }
    
    public static boolean isRepetido(Empleado empleado) {
        for (Empleado e : getEmpleados())
            if (e.getCedula().equals(empleado.getCedula()))
                return true;
        
        return false;
    }
    
    public static void add(Medico medico) {
        if (!isRepetido(medico)) {
            BasicDBObject documento = new BasicDBObject();
            documento.put("cedula", medico.getCedula());
            documento.put("nombre", medico.getNombre());
            
            BasicDBObject documento_educacion = new BasicDBObject();
            documento_educacion.put("tipo", medico.getEducacion().getTipo());
            documento_educacion.put("numero_registro", medico.getEducacion().getNumeroRegistro());
            documento.append("educacion", documento_educacion);
            
            coleccion = database.getCollection("Medicos");
            coleccion.insert(documento);
        }
    }
    
    public static void add(Enfermero enfermero) {
        if (!isRepetido(enfermero)) {
            BasicDBObject documento = new BasicDBObject();
            documento.put("cedula", enfermero.getCedula());
            documento.put("nombre", enfermero.getNombre());
            
            BasicDBObject documento_educacion = new BasicDBObject();
            documento_educacion.put("tipo", enfermero.getEducacion().getTipo());
            documento_educacion.put("numero_registro", enfermero.getEducacion().getNumeroRegistro());
            documento.append("educacion", documento_educacion);
            
            coleccion = database.getCollection("Enfermeros");
            coleccion.insert(documento);
        }
    }
    
    public static void remove(String cedula) {
        coleccion = database.getCollection("Medicos");
        coleccion.remove(new BasicDBObject().append("cedula", cedula));
        coleccion = database.getCollection("Enfermeros");
        coleccion.remove(new BasicDBObject().append("cedula", cedula));
    }
    
    public static Medico findMedico(String cedula) {
        for (Medico medico : getMedicos())
            if (medico.getCedula().equals(cedula))
                return medico;
        
        return null;
    }
    
    public static Enfermero findEnfermero(String cedula) {
        for (Enfermero enfermero : getEnfermeros())
            if (enfermero.getCedula().equals(cedula))
                return enfermero;
        
        return null;
    }
    
    public static Empleado findEmpleado(String cedula) {
        for (Empleado empleado : getEmpleados())
            if (empleado.getCedula().equals(cedula))
                return empleado;
        
        return null;
    }

}
