# Interfaz de usuario

```mermaid
flowchart LR

1[Log in]
        1.0.1[Ver Receta]
    1.1[Principal Admin]
        1.1.1[Registrar Paciente]
        1.1.2[Registrar Personal]
        1.1.3[Registrar Receta]
        1.1.4[Ver Paciente]
        1.1.5[Ver Personal]
    1.2[Principal Medico]
        1.2.1[Recetar]
        1.2.2[Programar Suministro]
        1.2.3[Ver Signos Vitales]
    1.3[Principal Enfermero]
        1.3.1[Confirmar Suministro]
        1.3.2[Tomar Signos Vitales]

1 --> 1.1
    1.1 --> 1.1.1
    1.1 --> 1.1.2
    1.1 --> 1.1.3
    1.1 --> 1.1.4
    1.1 --> 1.1.5
    1.1 --> 1.0.1
1 --> 1.2
    1.2 --> 1.0.1
    1.2 --> 1.2.1
    1.2.1 --> 1.2.2
    1.2 --> 1.2.3
1 --> 1.3
    1.3 --> 1.3.1
    1.3 --> 1.3.2
```