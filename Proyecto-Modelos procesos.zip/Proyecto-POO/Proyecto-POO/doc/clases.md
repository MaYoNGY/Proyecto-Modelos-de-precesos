# Clases

```mermaid
classDiagram

Medico --|> Empleado
Enfermero --|> Empleado
Educacion --* Empleado

Quimioterapia --|> Paciente
Terminal --|> Paciente

Receta ..> Medico
Medicamento --o Receta
Suministro -- Receta
Suministro ..> Enfermero
Paciente -- Receta

SignosVitales --* Paciente
Fecha --* SignosVitales
Fecha --|> Date

class Empleado {
    -String nombre
    -String cedula
    -Educacion educacion
}

class Medico

class Enfermero

class Receta {
    -Date fecha
    -Medico medico
    -String diagnostico
    -String indicaciones
    -Paciente tratado
    -ArrayList<Medicamento> medicamentos
}

class Suministro {
    -Date fecha
    -Receta receta
    -Medicamento medicamento
    -Enfermero enfermero
}

class Paciente {
    -String nombre
    -String cedula
    -ArrayList<String> historial
    -SignosVitales signosVitales
}

class Quimioterapia

class Terminal

class Medicamento {
    -String nombre
    -String dosis
}

class SignosVitales {
    -int frecuenciaCardiaca
    -int presionArterial
    -int talla
    -float temperatura
    -float peso
    -Fecha fecha
}

class Educacion {
    -String tipo
    -String numeroRegistro
}

class Fecha {
    -String horaString();
    -String fechaString();
    -String tiempoString();
}
```