# Requisitos

Crear una aplicación que ayude a un centro médico a realizar acciones como:

- Recetar y registrar la receta de un paciente.
- Dar seguimiento a la receta y el suministro de medicamentos a los pacientes.
- Registrar los signos vitales del paciente.
- Llevar un registro de los médicos y enfermeros encargados de atender a los pacientes.
